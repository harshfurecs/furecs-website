<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
    <!-- Meta Tags -->
    <!--Optimization-->
    <meta charset="UTF-8" />
    <meta http-equiv="Expires" content="30" />
    <title>Future Revolution - A Digital Marketing, Web Design & Development Company in Bengaluru.</title>
    <meta name="description" content="Future Revolution is a Digital Marketing, Web Design & Development agency work with passion to solve your online business needs.">
    <meta name="keywords" content="Future Revolution, Website Development Bangalore, Website Design in Bangalore, Digital Marketing Services, Website designers bangalore, Website Development Companies in Bangalore, Website Design Company Bangalore.">
    <meta name="author" content="Future Revolution">
    <meta name="language" content="English">
    <meta name="revisit-after" content="1 days">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <!-- Favicon Icon -->
    <link rel="icon" href="assets/img/favicon.png">
    <!-- Stylesheets -->
    <link rel="stylesheet" type="text/css" href="assets/css/plugins.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="assets/css/responsive.css">
    <link id="theme" rel="stylesheet" href="assets/css/color/color-1.css">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
  <script type="text/javascript" src="assets/vendor/backward/html5shiv.js"></script>
  <script type="text/javascript" src="assets/vendor/backward/respond.min.js"></script>
  <![endif]-->
</head>

<body data-spy="scroll" data-target=".primary-nav">


    <?php include'includes/header.php' ?>

    <!--Main Banner Breadcrumb-->
    <div class="banner_section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="text-left">About us</h2>
                    <p><a href="index.php">Home</a> <span>/</span> About us</p>
                </div>
            </div>
        </div>
    </div>
    <!--End Banner-->

    <!-- About Section -->
    <section class="about-section" style="background-image: url(assets/img/about/1.jpg);">
        <div class="full-max-width">
            <div class="row no-gutters">
                <!-- Image Column -->
                <div class="image-column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <div class="title-box wow fadeInLeft" data-wow-delay='1200ms'>
                            <h2>4 <br>Years</h2>
                            <span class="sub-title">On The Market</span>
                        </div>
                        <div class="image-box wow fadeInRight" data-wow-delay='600ms'>
                            <figure class="image"><img src="assets/img/about/image-1.jpg" alt=""></figure>
                        </div>
                    </div>
                </div>

                <!-- Content Column -->
                <div class="content-column col-lg-6 col-md-12 col-sm-12">
                    <div class="inner-column wow fadeInLeft">
                        <div class="content-box">
                            <div class="sec-title">
                                <h2>About Us</h2>
                            </div>
                            <div class="text text-justify">Future Revolution is an innovative company which is aimed at providing new trends in the field of software designing and development. This is done in accordance with the software development standards to provide compatible software solutions. Future Revolution has a capacious domain savvy persons, with vast experience in technology. Our offshore Application Development team is best suited to understand and analyse the application requirements, then architect, develop, test its endurance, and finally deploy it to the clients with post project delivery management and support services.</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End About Section -->

    <!--Reason Section-->
    <section class="reason-section">
        <div class="container-fluid">
            <div class="row clearfix">

                <!--Image Column-->
                <div class="image-column col-lg-4 col-md-12 col-sm-12">
                    <div class="image">
                        <img src="assets/img/about/why-choose-us.png" alt="" />
                    </div>
                </div>

                <!--Content Column-->
                <div class="content-column col-lg-8 col-md-12 col-sm-12">
                    <div class="inner-column">
                        <div class="sec-title">
                            <div class="title">Whats Reasons</div>
                            <h2>Why Choose Us</h2>
                        </div>
                        <div class="text">Our well-built sense of identification with client and clients’ projects means that we are constantly aiming to provide solutions. To this end, we adopt a developing approach to technology and marketing techniques. This sense of rapport also means we appreciate and promote seamless interaction with clients’ own teams, and guarantee the best value is obtained from their event budget.</div>
                        <div class="row clearfix">
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <ul class="reason-list">
                                    <li>
                                        <span class="icon fa fa-briefcase"></span>
                                        Committed to quality
                                    </li>
                                </ul>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <ul class="reason-list">
                                    <li>
                                        <span class="icon fa fa-diamond"></span>
                                        Security is Key Feature
                                    </li>
                                </ul>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <ul class="reason-list">
                                    <li>
                                        <span class="icon fa fa-bank"></span>
                                        One Stop Solutions
                                    </li>
                                </ul>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <ul class="reason-list">
                                    <li>
                                        <span class="icon fa fa-user"></span>
                                        Our Customers Our Asset
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!--End Reason Section-->


    <!-- Start Call To Action -->
    <section class="cta section overlay-with-img cta-2">
        <img src="assets/img/call-to-action-bg.jpg" alt="" class="bg-img">
        <div class="fun-overlay"></div>
        <div class="container">
            <div class="cta-text">
                <div class="cta-btn">
                    <a href="#contact" class="tm-btn"><span>Contact Us</span></a>
                    <div class="cta-bar"></div>
                </div>
                <h2>
                    <span>
                        <span class="wow fadeInLeft" data-wow-duration="2s" data-wow-delay="0.1s">START BUILDING YOUR NEXT PROJECT WITH US</span>
                    </span>
                </h2>
            </div>
        </div>
    </section>
    <!-- End Call To Action -->

    <!-- Start Client Logo -->
    <div class="client-logo-wrap section" id="clients">
        <div class="container">
            <div class="section-head text-center">
                <h2>Our Clients</h2>
                <div class="section-divider">
                    <div class="left wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                    <span></span>
                    <div class="right wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                </div>
                <p>We work with organisations of any size</p>
            </div>

            <div class="container">
                <section class="customer-logos slider">
                    <div class="slide"><img src="assets/img/clients/1.png"></div>
                    <div class="slide"><img src="assets/img/clients/2.png"></div>
                    <div class="slide"><img src="assets/img/clients/3.png"></div>
                    <div class="slide"><img src="assets/img/clients/4.png"></div>
                    <div class="slide"><img src="assets/img/clients/5.png"></div>
                    <div class="slide"><img src="assets/img/clients/6.png"></div>
                    <div class="slide"><img src="assets/img/clients/7.png"></div>
                    <div class="slide"><img src="assets/img/clients/8.png"></div>
                    <div class="slide"><img src="assets/img/clients/9.png"></div>
                    <div class="slide"><img src="assets/img/clients/10.png"></div>
                    <div class="slide"><img src="assets/img/clients/11.png"></div>
                    <div class="slide"><img src="assets/img/clients/12.png"></div>
                </section>
            </div>
        </div>
    </div>
    <!-- End Client Logo -->



    <!-- Start Client Logo -->
    <div class="client-logo-wrap section" id="partner">
        <div class="container">
            <div class="section-head text-center">
                <h2>Our Partners</h2>
                <div class="section-divider">
                    <div class="left wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                    <span></span>
                    <div class="right wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                </div>
            </div>

            <div class="container">
                <div class="tab">

                    <ul class="tabs">
                        <li><a href="#">Tally</a></li>
                        <li><a href="#">Instamojo</a></li>
                        <li><a href="#">Smart Click</a></li>
                        <li><a href="#">GoDaddy</a></li>
                        <li><a href="#">MyOperator</a></li>
                        <li><a href="#">Biz Analyst</a></li>
                    </ul> <!-- / tabs -->

                    <div class="tab_content">

                        <div class="tabs_item">
                            <div class="col-xs-12 col-sm-12 col-lg-12 col-xs-12">
                                <div class="row">
                                    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                        <img src="assets/img/partners/1.png">
                                    </div>
                                    <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 m-t30">
                                        <h4>Tally</h4>
                                        <p>Tally.ERP 9 is GST-Ready ERP software used for Billing, Accounting, Inventory Management and Purchases by over million businesses across 100 countries.</p>
                                    </div>
                                </div>
                            </div>
                        </div> <!-- / tabs_item -->

                        <div class="tabs_item">
                            <div class="col-xs-12 col-sm-12 col-lg-12 col-xs-12">
                                <div class="row">
                                    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                        <img src="assets/img/partners/2.png">
                                    </div>
                                    <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 m-t30">
                                        <h4>Instamojo</h4>
                                        <p>Instamojo provides free payment gateway in India. Trusted by 600000+ Indian Businesses, 100% Secure, No setup cost, No maintenance cost.</p>
                                    </div>
                                </div>
                            </div>
                        </div> <!-- / tabs_item -->

                        <div class="tabs_item">
                            <div class="col-xs-12 col-sm-12 col-lg-12 col-xs-12">
                                <div class="row">
                                    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                        <img src="assets/img/partners/3.png">
                                    </div>
                                    <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 m-t30">
                                        <h4>Smart Click</h4>
                                        <p>SMART CLICK is the company of unparalleled concept of creative business with enormous future growth potentiality and proven resilience.</p>
                                    </div>
                                </div>
                            </div>
                        </div> <!-- / tabs_item -->

                        <div class="tabs_item">
                            <div class="col-xs-12 col-sm-12 col-lg-12 col-xs-12">
                                <div class="row">
                                    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                        <img src="assets/img/partners/4.png">
                                    </div>
                                    <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 m-t30">
                                        <h4>GoDaddy</h4>
                                        <p>GoDaddy makes registering Domain Names fast, simple, and affordable. Find out why so many business owners chose GoDaddy to be their Domain Name.</p>
                                    </div>
                                </div>
                            </div>
                        </div> <!-- / tabs_item -->

                        <div class="tabs_item">
                            <div class="col-xs-12 col-sm-12 col-lg-12 col-xs-12">
                                <div class="row">
                                    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                        <img src="assets/img/partners/5.png">
                                    </div>
                                    <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 m-t30">
                                        <h4>MyOperator</h4>
                                        <p>MyOperator is a cloud-based call management system that provides solutions such as IVR, virtual number, toll free number, virtual PBX, etc for businesses.</p>
                                    </div>
                                </div>
                            </div>
                        </div> <!-- / tabs_item -->
                        
                        <div class="tabs_item">
                            <div class="col-xs-12 col-sm-12 col-lg-12 col-xs-12">
                                <div class="row">
                                    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                        <img src="assets/img/partners/6.png">
                                    </div>
                                    <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 m-t30">
                                        <h4>Biz Analyst</h4>
                                        <p>Tally ERP 9 App for your Android and IOS which allows you to access your tally ERP 9 Data on your fingertips in real time.</p>
                                    </div>
                                </div>
                            </div>
                        </div> <!-- / tabs_item -->

                    </div> <!-- / tab_content -->
                </div> <!-- / tab -->
            </div>
        </div>
    </div>
    <!-- End Client Logo -->



    <?php include'includes/footer.php' ?>

</body>

</html>
