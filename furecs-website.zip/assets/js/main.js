(function ($) {

    "use strict";

    /*--------------------------------------------------------------
    	1. Scripts initialization
    --------------------------------------------------------------*/

    $(window).on('load', function () {
        $(window).trigger("scroll");
        $(window).trigger("resize");
        preloaderSetup();
        portfolioMsSetup();
    });

    $(document).on('ready', function () {
        $(window).trigger("resize");
        primaryMenuSetup();
        mobileMenu();
        scrollAnimation();
        sectionActive();
        scrollUp();
        owlCarouselSetup();
        portfolioMsSetup();
        rippleSetup();
        new WOW().init();
        $(".player").YTPlayer();
        $('.parallax').parallax("50%", 0.3);
        $('.counter').tamjidCounter();
    });

    $(document).ready(function () {
        $('#testimonial-slider').owlCarousel({
            items: 1,
            itemsDesktop: [1000, 1],
            itemsDesktopSmall: [979, 1],
            itemsTablet: [768, 1],
            pagination: true,
            navigation: true,
            navigationText: ["", ""],
            slideSpeed: 1000,
            autoPlay: true
        });
    });
    $(document).ready(function () {
        $('.customer-logos').slick({
            slidesToShow: 6,
            slidesToScroll: 1,
            autoplay: true,
            autoplaySpeed: 1500,
            arrows: false,
            dots: false,
            pauseOnHover: false,
            responsive: [{
                breakpoint: 768,
                settings: {
                    slidesToShow: 4
                }
        }, {
                breakpoint: 520,
                settings: {
                    slidesToShow: 3
                }
        }]
        });
    });

     $(window).on('resize', function () {
        mobileMenu();
        portfolioMsSetup();
    });

    $(window).on('scroll', function () {
        scrollFunction();
    });

    $.exists = function (selector) {
        return ($(selector).length > 0);
    }
    /*--------------------------------------------------------------
    	2. Preloader
    --------------------------------------------------------------*/

    function preloaderSetup() {

        $("body").imagesLoaded(function () {
            $(".preloader-wave").fadeOut();
            $("#preloader").delay(200).fadeOut("slow").remove();
        });

    }

    /* ==================================================
           # Clients Carousel
        ===============================================*/
    $('.clients-items').owlCarousel({
        loop: false,
        margin: 30,
        nav: true,
        navText: [
                "<i class='fa fa-long-arrow-alt-left'></i>",
                "<i class='fa fa-long-arrow-alt-right'></i>"
            ],
        dots: false,
        autoplay: true,
        responsive: {
            0: {
                items: 2
            },
            600: {
                items: 3
            },
            1000: {
                items: 5
            }
        }
    });



    /*--------------------------------------------------------------
    	3. Primary Menu
    --------------------------------------------------------------*/

    function primaryMenuSetup() {

        $(".m-menu-btn").on('click', function () {
            $(this).toggleClass("m-menu-btn-ext");
            $(this).siblings('.primary-nav-list').slideToggle("slow");
        });

        $(".menu-item-has-children > ul").before("<i class='fa fa-plus m-dropdown'></i>");
        $('.m-dropdown').on('click', function () {
            $(this).siblings('ul').slideToggle("slow");
            $(this).toggleClass("fa-plus fa-minus")
        });

    }

    function mobileMenu() {

        if ($(window).width() <= 983) {
            $('.primary-nav').addClass('m-menu').removeClass('primary-nav');
        } else {
            $('.m-menu').addClass('primary-nav').removeClass('m-menu');
        }

    }

    /*--------------------------------------------------------------
    	4. Scroll Function
    --------------------------------------------------------------*/

    function scrollFunction() {

        var scroll = $(window).scrollTop();

        if (scroll >= 10) {
            $(".site-header").addClass("small-height");
        } else {
            $(".site-header").removeClass("small-height");
        }
        // For Scroll Up
        if (scroll >= 350) {
            $("#scrollup").addClass("scrollup-show");
        } else {
            $("#scrollup").removeClass("scrollup-show");
        }

    }

    /*--------------------------------------------------------------
    	5. Section Active and Scrolling Animation
    --------------------------------------------------------------*/

    function scrollAnimation() {

        $('a:not(.portfolio-filter ul li a):not(.portfolio-item .item-inner):not(.nav-tabs a)').on('click', function (event) {
            var $anchor = $(this);
            $('html, body').stop().animate({
                scrollTop: ($($anchor.attr('href')).offset().top - 30)
            }, 1250, 'easeInOutExpo');
            event.preventDefault();
        });

    }

    function sectionActive() {

        $('body').scrollspy({
            target: '.site-header',
            offset: 70
        });

    }


    /*--------------------------------------------------------------
    	6. Scroll Up
    --------------------------------------------------------------*/

    function scrollUp() {

        $('#scrollup').on('click', function (e) {
            e.preventDefault();
            $('html,body').animate({
                scrollTop: 0
            }, 1000);
        });

    }

    /*--------------------------------------------------------------
    	7. Owl Carousel
    --------------------------------------------------------------*/

    function owlCarouselSetup() {

        /* Owl Carousel For hero-slider */
        $('.tm-hero-slider2').owlCarousel({
            items: 1,
            animateOut: 'fadeOut',
            loop: true,
            nav: true,
            navText: ['<i class="fa fa-caret-left"></i>', '<i class="fa fa-caret-right"></i>'],
            autoplay: false
        });
        /* Owl Carousel For hero-slider */
        $('.tm-hero-slider3').owlCarousel({
            items: 1,
            animateOut: 'slideOutDown',
            animateIn: 'flipInX',
            loop: true,
            nav: true,
            autoplayTimeout: 6000,
            smartSpeed: 1000,
            navText: ['<i class="icofont-bubble-left"></i>', '<i class="icofont-bubble-right"></i>'],
            autoplay: false
        });

    }

    /*--------------------------------------------------------------
    	8. Portfolio
    --------------------------------------------------------------*/

    function portfolioMsSetup() {

        if ($.exists('.portfolio')) {

            $('.portfolio').isotope({
                itemSelector: '.portfolio-item',
                transitionDuration: '0.60s',
                percentPosition: true,
                masonry: {
                    columnWidth: '.grid-sizer'
                }
            });

            /* Active Class of Portfolio*/
            $('.portfolio-filter ul li').on('click', function (event) {
                $(this).siblings('.active').removeClass('active');
                $(this).addClass('active');
                event.preventDefault();
            });

            /*=== Portfolio filtering ===*/
            $('.portfolio-filter ul').on('click', 'a', function () {
                var filterElement = $(this).attr('data-filter');
                $(this).parents(".portfolio-filter").next().isotope({
                    filter: filterElement
                });
            });
        }

    }

    /*--------------------------------------------------------------
    	9. Ripple
    --------------------------------------------------------------*/

    function rippleSetup() {

        if ($.exists('.ripple-version')) {

            $('.ripple-version').ripples({
                resolution: 512,
                dropRadius: 20,
                perturbance: 0.04,
            });

        }

    }


    /*--------------------------------------------------------------
        14. Particle JS
    --------------------------------------------------------------*/

    if ($.exists('#particles')) {
        document.addEventListener('DOMContentLoaded', function () {
            particleground(document.getElementById('particles'), {
                dotColor: 'rgba(32, 48, 60, 0.4)',
                lineColor: 'rgba(32, 48, 60, 0.1)'
            });
            var intro = document.getElementById('intro');
        }, false);

    }


    /*--------------------------------------------------------------
        16. Parallax 2
    --------------------------------------------------------------*/
    if ($.exists('#tm-scene')) {

        var scene = document.getElementById('tm-scene');
        var parallax = new Parallax(scene);

    }

    /*--------------------------------------------------------------
	    ## Color Customizer
	--------------------------------------------------------------*/
    $(document).ready(function () {
        $("button[data-theme]").on('click', function () {
            $("head link#theme").attr("href", $(this).data("theme"));
        });
        $('.customizer-btn').on('click', function () {
            $(this).parent().toggleClass('cs-hide');
        })
    });

    /*******************work process***************/
    $(document).ready(function () {

        (function ($) {
            $('.tab ul.tabs').addClass('active').find('> li:eq(0)').addClass('current');

            $('.tab ul.tabs li a').click(function (g) {
                var tab = $(this).closest('.tab'),
                    index = $(this).closest('li').index();

                tab.find('ul.tabs > li').removeClass('current');
                $(this).closest('li').addClass('current');

                tab.find('.tab_content').find('div.tabs_item').not('div.tabs_item:eq(' + index + ')').slideUp();
                tab.find('.tab_content').find('div.tabs_item:eq(' + index + ')').slideDown();

                g.preventDefault();
            });
        })(jQuery);

    });
    /*******************work process***************/
    $.fn.ashCordian = function () {

        var container = $(this);

        container.find('header').click(function () {
            if ($(this).siblings('section').css('display') == 'block') {
                container.find('section').slideUp(150);
            } else {
                container.find('section').slideUp(150);
                $(this).siblings('section').slideDown(150);
            }
        });
    };


    $('#accord1').ashCordian();

    // ------------------------------------------------------------------------------ //
    // Toggle Side Menu
    // ------------------------------------------------------------------------------ //
    $(".primary-nav-list").each(function () {
        $("li.side-menu > a", this).on("click", function (e) {
            e.preventDefault();
            $("header.site-header > .side").toggleClass("on");
            $("body").toggleClass("on-side");
        });
    });
    $(".side .close-side").on("click", function (e) {
        e.preventDefault();
        $("header.site-header > .side").removeClass("on");
        $("body").removeClass("on-side");
    });


})(jQuery); // End of use strict
