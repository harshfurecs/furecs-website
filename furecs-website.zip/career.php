<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
    <!-- Meta Tags -->
    <!--Optimization-->
    <meta charset="UTF-8" />
    <meta http-equiv="Expires" content="30" />
    <title>Future Revolution - A Digital Marketing, Web Design & Development Company in Bengaluru.</title>
    <meta name="description" content="Future Revolution is a Digital Marketing, Web Design & Development agency work with passion to solve your online business needs.">
    <meta name="keywords" content="Future Revolution, Website Development Bangalore, Website Design in Bangalore, Digital Marketing Services, Website designers bangalore, Website Development Companies in Bangalore, Website Design Company Bangalore.">
    <meta name="author" content="Future Revolution">
    <meta name="language" content="English">
    <meta name="revisit-after" content="1 days">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <!-- Favicon Icon -->
    <link rel="icon" href="assets/img/favicon.png">
    <!-- Stylesheets -->
    <link rel="stylesheet" type="text/css" href="assets/css/plugins.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="assets/css/responsive.css">
    <link id="theme" rel="stylesheet" href="assets/css/color/color-1.css">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
  <script type="text/javascript" src="assets/vendor/backward/html5shiv.js"></script>
  <script type="text/javascript" src="assets/vendor/backward/respond.min.js"></script>
  <![endif]-->
</head>

<body data-spy="scroll" data-target=".primary-nav">

    <?php include'includes/header.php' ?>

    <!--Main Banner Breadcrumb-->
    <div class="banner_section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="text-left">Career</h2>
                    <p><a href="index.php">Home</a> <span>/</span> Career</p>
                </div>
            </div>
        </div>
    </div>
    <!--End Banner-->

    <!-- contact area -->
    <div class="section">
        <!-- Browse Jobs -->
        <div class="browse-job">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12 col-lg-12">
                        <ul class="post-job-bx">
                            <li class="job_list">
                                <div class="job-post-location">
                                    <ul>
                                        <li><i class="fa fa-map-marker"></i> Bangalore, Karnataka</li>
                                        <li><i class="fa fa-bookmark-o"></i> Full Time</li>
                                        <li><i class="fa fa-clock-o"></i> Published 11 months ago</li>
                                    </ul>
                                </div>
                                <div class="d-flex">
                                    <div class="job-post-company">
                                        <span><img src="https://s3.ap-south-1.amazonaws.com/dzon-html/job-board/xhtml/images/logo/icon1.png" /></span>
                                    </div>
                                    <a href="job_detail.php">
                                        <div class="job-post-info">
                                            <h4>Digital Marketing Executive</h4>
                                        </div>

                                    </a>
                                </div>
                                <div class="job-description">
                                    <p><span>Job-Description :</span> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                                    </p>
                                </div>
                                <a href="job_detail.php">
                                    <div class="job-time d-inline-block">
                                        <span>Apply Now</span>
                                    </div>
                                </a>
                                <div class="salary-bx d-inline-block pull-right">
                                    <span><i class="fa fa-rupee"></i> 12000 - <i class="fa fa-rupee"></i> 25000</span>
                                </div>
                            </li>
                            <li class="job_list">
                                <div class="job-post-location">
                                    <ul>
                                        <li><i class="fa fa-map-marker"></i> Bangalore, Karnataka</li>
                                        <li><i class="fa fa-bookmark-o"></i> Full Time</li>
                                        <li><i class="fa fa-clock-o"></i> Published 11 months ago</li>
                                    </ul>
                                </div>
                                <div class="d-flex">
                                    <div class="job-post-company">
                                        <span><img src="https://s3.ap-south-1.amazonaws.com/dzon-html/job-board/xhtml/images/logo/icon1.png" /></span>
                                    </div>
                                    <a href="job_detail.php">
                                        <div class="job-post-info">
                                            <h4>Digital Marketing Executive</h4>
                                        </div>
                                    </a>

                                </div>
                                <div class="job-description">
                                    <p><span>Job-Description :</span> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                                    </p>
                                </div>
                                <a href="job_detail.php">
                                    <div class="job-time d-inline-block">
                                        <span>Apply Now</span>
                                    </div>
                                </a>
                                <div class="salary-bx d-inline-block pull-right">
                                    <span><i class="fa fa-rupee"></i> 12000 - <i class="fa fa-rupee"></i> 25000</span>
                                </div>
                            </li>
                            <li class="job_list">
                                <div class="job-post-location">
                                    <ul>
                                        <li><i class="fa fa-map-marker"></i> Bangalore, Karnataka</li>
                                        <li><i class="fa fa-bookmark-o"></i> Full Time</li>
                                        <li><i class="fa fa-clock-o"></i> Published 11 months ago</li>
                                    </ul>
                                </div>
                                <div class="d-flex">
                                    <div class="job-post-company">
                                        <span><img src="https://s3.ap-south-1.amazonaws.com/dzon-html/job-board/xhtml/images/logo/icon1.png" /></span>
                                    </div>
                                    <a href="job_detail.php">
                                        <div class="job-post-info">
                                            <h4>Digital Marketing Executive</h4>
                                        </div>
                                    </a>
                                </div>
                                <div class="job-description">
                                    <p><span>Job-Description :</span> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                                    </p>
                                </div>
                                <a href="job_detail.php">
                                    <div class="job-time d-inline-block">
                                        <span>Apply Now</span>
                                    </div>
                                </a>
                                <div class="salary-bx d-inline-block pull-right">
                                    <span><i class="fa fa-rupee"></i> 12000 - <i class="fa fa-rupee"></i> 25000</span>
                                </div>
                            </li>
                            <li class="job_list">
                                <div class="job-post-location">
                                    <ul>
                                        <li><i class="fa fa-map-marker"></i> Bangalore, Karnataka</li>
                                        <li><i class="fa fa-bookmark-o"></i> Full Time</li>
                                        <li><i class="fa fa-clock-o"></i> Published 11 months ago</li>
                                    </ul>
                                </div>
                                <div class="d-flex">
                                    <div class="job-post-company">
                                        <span><img src="https://s3.ap-south-1.amazonaws.com/dzon-html/job-board/xhtml/images/logo/icon1.png" /></span>
                                    </div>
                                    <a href="job_detail.php">
                                        <div class="job-post-info">
                                            <h4>Digital Marketing Executive</h4>
                                        </div>
                                    </a>

                                </div>
                                <div class="job-description">
                                    <p><span>Job-Description :</span> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                                    </p>
                                </div>
                                <a href="job_detail.php">
                                    <div class="job-time d-inline-block">
                                        <span>Apply Now</span>
                                    </div>
                                </a>
                                <div class="salary-bx d-inline-block pull-right">
                                    <span><i class="fa fa-rupee"></i> 12000 - <i class="fa fa-rupee"></i> 25000</span>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Browse Jobs END -->

    <!-- Content END-->


    <?php include'includes/footer.php' ?>

</body>

</html>
