<?php
if(isset($_POST['submit']))
{
   extract($_POST); 
    $to="marketing@furecs.com"; 
    $strSubject="Future Revolution Contact Form";
    $message =  "<table width='100%' border='1' cellspacing='0' cellpadding='0'>
                <tr>
                <td width='10%' colspan='4' bgcolor='#000' style='padding:5px; color: #fff; font-weight:bold;'>
                     Enquiry Data</td>
                </tr>
                <tr>
                <td style='padding:5px;font-weight:bold;'>Name </td>
                <td style='padding:5px;'>".$form_name."</td>
                </tr>
                <tr>
                <td style='padding:5px;font-weight:bold;'>Email </td>
                <td style='padding:5px;'>".$form_email."</td>
                </tr>
                <tr>
                <td style='padding:5px;font-weight:bold;'>Phone number </td>
                <td style='padding:5px;'>".$form_phone."</td>
                </tr>
               
                
             
               
                
               
                </table>";              
    $headers = 'MIME-Version: 1.0'."\r\n";
    $headers .= 'Content-type: text/html; charset=UTF-8'."\r\n";
    $from = 'contact@furecs.com'; // a valid address on your domain
    $headers .= "From: $from\r\nReply-to: $email";
    $mail_sent=mail($to, $strSubject, $message, $headers);  
if($mail_sent)
        echo "<script>
               window.location='https://furecs.com/';exit();</script>";
    else
        echo "<script>
             window.location='https://furecs.com/';exit();</script>";
}
?>
