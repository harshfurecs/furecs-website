
    <!-- Start Site Footer -->
    <footer class="site-footer">
        <div class="top-footer">
            <div class="container">
                <div class="row">
                    <div class="col-md-3">
                        <div class="footer-widget">
                            <div class="footer-about-widget">
                                <img src="assets/img/footer-logo.png" alt="">
                                <p>FUTURE REVOLUTION as a One Stop Solution company for all your business needs.</p>
                            </div>
                        </div><!-- .footer-widget -->
                    </div><!-- .col -->
                    <div class="col-md-3">
                        <div class="footer-widget">
                            <h2 class="footer-widget-title">Quick Links</h2>
                            <div class="footer-divider">
                                <div class="left wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.2s; animation-name: fadeInLeft;"></div>
                                <span></span>
                                <div class="right wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.2s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.2s; animation-name: fadeInRight;"></div>
                            </div>
                            <ul class="footer-links">
                                <li><a href="about-us.php">About Us</a></li>
                                <li><a href="https://furecs.com/blog/">Blog</a></li>
                                <li><a href="career.php">Career</a></li>
                                <li><a href="privacy-policy.php">Privacy Policy</a></li>
                                <li><a href="terms-and-condition.php">Terms and Conditions</a></li>
                            </ul>
                        </div><!-- .footer-widget -->
                    </div><!-- .col -->
                    <div class="col-md-3">
                        <div class="footer-widget">
                            <h2 class="footer-widget-title">Services</h2>
                            <div class="footer-divider">
                                <div class="left wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.2s; animation-name: fadeInLeft;"></div>
                                <span></span>
                                <div class="right wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.2s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.2s; animation-name: fadeInRight;"></div>
                            </div>
                            <ul class="footer-links">
                                <li><a href="graphic-design.php">Graphic Design</a></li>
                                <li><a href="website-design.php">Website Design</a></li>
                                <li><a href="web-development.php">Web Development</a></li>
                                <li><a href="digital-marketing.php">Digital Marketing</a></li>
                                <li><a href="recruitment.php">Recruitment</a></li>
                                <li><a href="tally-solution.php">Tally Solutions</a></li>
                            </ul>
                        </div><!-- .footer-widget -->
                    </div><!-- .col -->
                    <div class="col-md-3">
                        <div class="footer-widget">
                            <h2 class="footer-widget-title">Contact Us</h2>
                            <div class="footer-divider">
                                <div class="left wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.2s; animation-name: fadeInLeft;"></div>
                                <span></span>
                                <div class="right wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.2s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.2s; animation-name: fadeInRight;"></div>
                            </div>
                            <div class="contact-info footer-contact">
                                <ul>
                                    <li><i class="icofont icofont-location-arrow"></i> #216/13, 4th Floor,<br /> Suraj Towers,<br />
                                        27th Cross, 3rd Block Jayanagar,<br />
                                        Bangalore-560 011.</li>
                                    <li><i class="icofont icofont-phone"></i> +91 7760556363</li>
                                    <li><i class="icofont icofont-email"></i> <a href="mailto:contact@furecs.com">contact@furecs.com</a></li>
                                </ul>
                            </div>
                        </div><!-- .footer-widget -->
                    </div><!-- .col -->
                </div>
            </div>
        </div>
        <div class="bottom-footer text-center">
            <div class="container">
                <div class="copy-right">Copyright © 2019 Future Revolution. All Rights Reserved.</div>
            </div>
        </div>
    </footer>
    <!-- End Site Footer -->

    <!-- Scroll Up -->
    <div id='scrollup'></div>

    <!-- Color Customizer -->
    <section class="color-customizer">
        <h2>Enquire Now</h2>
        <div class="customizer-btn"><span>Enquire Now</span></div>
        <div class="container">
            <form action="https://furecs.com/contact_mailer.php" class="row contact-form" method="post" id="contact-form" onSubmit="alert('Thank for enquiry, We will get back you soon.');">
                <div class="col-lg-12">
                    <div class="tm-form-field eq-form-field">
                        <input type="text" id="name" name="form_name" required>
                        <span class="bar"></span>
                        <label>Full Name*</label>
                    </div>
                    <div class="tm-form-field eq-form-field">
                        <input type="email" id="email" name="form_email" required>
                        <span class="bar"></span>
                        <label>Email Address*</label>
                    </div>
                    <div class="tm-form-field eq-form-field">
                        <input type="number" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==10) return false;" id="phone" name="form_phone" required>
                        <span class="bar"></span>
                        <label>Phone*</label>
                    </div>
                    <button class="cont-submit btn-contact tm-btn tm-btn-black" type="submit" id="submit" name="submit">
                        <span>Send</span>
                        <i class="sp-btn"></i>
                    </button>
                </div><!-- .col -->
            </form>
        </div>
    </section>
    <!-- End Customizer -->

    <!-- Start Whatsapp and call plugin -->
    <div class="whatsapp_div">
        <a href="https://api.whatsapp.com/send?phone=917760556363&text=Hello%20Future%20Revolution,%20I%20am%20happy%20to%20be%20your%20Customer!!%20Please%20Share%20me%20more%20details%20on%20-%20" class="btn whatsappbtn">

            <div class="what_txt">
                <i class="fa fa-whatsapp"></i>
            </div>
        </a>

    </div>
    <div class="call_div">
        <a href="tel:+917760556363" class="btn callbtn">
            <div>
                <i class="fa fa-phone inline-block"></i>
                <span class="what_txt inline-block d-none d-md-block d-lg-block d-xs-none d-sm-none">Give A Missed Call</span>
            </div>
        </a>
    </div>
    <!-- End Whatsapp and call plugin -->

    <!-- /.modal -->
    <div id="quotemodal" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Get A Quote</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>
                <div class="modal-body">
                    <form action="https://furecs.com/contact_mailer1.php" class="row contact-form" method="post" id="contact-form1" onSubmit="alert('successfully Sent.');">

                        <div class="col-lg-12">
                            <div class="tm-form-field eq-form-field">
                                <input type="text" id="name" name="form_name" required>
                                <span class="bar"></span>
                                <label>Full Name*</label>
                            </div>
                            <div class="tm-form-field eq-form-field">
                                <input type="email" id="email" name="form_email" required>
                                <span class="bar"></span>
                                <label>Email Address*</label>
                            </div>
                            <div class="tm-form-field eq-form-field">
                                <input type="number" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==10) return false;" id="phone" name="form_phone" required>
                                <span class="bar"></span>
                                <label>Phone*</label>
                            </div>
                            <div class="tm-form-field eq-form-field">
                                <select required name="form_graphic">
                                    <option selected disabled>Regrading*</option>
                                    <option value="Graphic Design">Graphic Design</option>
                                    <option value="Website Design">Website Design</option>
                                    <option value="Web Development">Web Development</option>
                                    <option value="Digital Marketing">Digital Marketing</option>
                                    <option value="Recruitment">Recruitment</option>
                                    <option value="Tally Solutions">Tally Solutions</option>
                                    <option value="Others">Others</option>
                                </select>
                            </div>
                            <div class="tm-form-field">
                                <textarea cols="30" rows="10" id="msg" name="form_message" required></textarea>
                                <span class="bar"></span>
                                <label>Your Message*</label>
                            </div>
                        </div><!-- .col -->

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button class="cont-submit btn-contact submit-btn tm-btn" type="submit" id="submit" name="submit">
                        <span>Send</span>
                        <i class="sp-btn"></i>
                    </button>
                </div>
                </form>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->

    <!-- Scripts -->
    <script src="assets/js/vendor/modernizr-3.5.0.min.js"></script>
    <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="assets/js/slick.js"></script>
    <script <script src="assets/js/plugins.js"></script>
    <script src="assets/js/main.js"></script>
    <script type="text/javascript" src="assets/js/jquery.validate.min.js"></script>
    <script type="text/javascript">
        $('#contact-form').validate();
        $('#contact-form1').validate();
        $('#contact-form2').validate();

    </script>