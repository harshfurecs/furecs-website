   <!-- Preloader -->
    <div id="preloader">
        <div class="preloader-wave"></div>
        <div class="preloader-wave"></div>
        <div class="preloader-wave"></div>
        <div class="preloader-wave"></div>
        <div class="preloader-wave"></div>
    </div>
    <!-- Preloader -->

<!-- Start Site Header -->
    <header class="site-header">
        <div class="header-wrap">
            <div class="container">
                <div class="site-branding">
                    <!-- For Image Logo -->
                    <a href="index.php" class="custom-logo-link">
                        <img src="assets/img/logo.png" alt="" class="custom-logo">
                    </a>
                    <!-- For Site Title -->
                    <!-- <span class="site-title">
          <a href="index.html">Stray</a>
          </span> -->
                </div>
                <nav class="primary-nav">
                    <div class='m-menu-btn'><span></span></div>
                    <ul class="primary-nav-list">
                        <li class="menu-item current-menu-ancestor current-menu-parent"><a href="#home" class="nav-link">HOME</a>
                        </li>
                        <li class="menu-item"><a href="#about" class="nav-link">ABOUT</a></li>
                        <li class="menu-item"><a href="#service" class="nav-link">SERVICE</a></li>
                        <li class="menu-item"><a href="#process" class="nav-link">WORK PROCESS</a></li>
                        <li class="menu-item"><a href="#clients" class="nav-link">OUR CLIENTS</a></li>
                        <li class="menu-item"><a href="#contact" class="nav-link">CONTACT</a></li>
                        <li class="side-menu"><a href="#"><i class="fa fa-bars"></i></a></li>
                    </ul>
                </nav>
            </div>
        </div><!-- .header-wrap -->

        <!-- Start Side Menu -->
        <div class="side">
            <a href="#" class="close-side"><i class="fa fa-times"></i></a>
            <div class="widget">
                <h4 class="title">Get in touch with us Today !!</h4>
                <div class="address">
                    <ul>
                        <li>
                            <div class="icon">
                                <i class="fa fa-map-marker"></i>
                            </div>
                            <div class="info">
                                <span>Future Revolution</span>
                                3rd Block Jayanagar,Bangalore.
                            </div>
                        </li>
                        <li>
                            <div class="icon">
                                <i class="fa fa-envelope-open"></i>
                            </div>
                            <div class="info">
                                <span>Online Support</span> contact@furecs.com marketing@furecs.com
                            </div>
                        </li>
                        <li>
                            <div class="icon">
                                <i class="fa fa-mobile"></i>
                            </div>
                            <div class="info">
                                <span>Customer Support</span>
                                +91 8448448964
                            </div>
                        </li>
                        <li>
                            <div class="icon">
                                <i class="fa fa-phone"></i>
                            </div>
                            <div class="info">
                                <span>Mon-Fri 9am-6pm</span>
                                +91 7760556363
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="widget social">
                <h4 class="title"> Follow us on Social </h4>
                <ul class="link">
                    <li class="facebook"><a href="https://www.facebook.com/myfuturerevolution/" target="_blank"><i class="fa fa-facebook-f"></i></a></li>
                    <li class="twitter"><a href="https://twitter.com/furec_s" target="_blank"><i class="fa fa-twitter"></i></a></li>
                    <li class="twitter"><a href="https://www.linkedin.com/company/futurerevolutions/" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                    <li class="pinterest"><a href="https://plus.google.com/u/0/111077966233344889458" target="_blank"><i class="fa fa-google-plus"></i></a></li>
                </ul>
            </div>
        </div>
        <!-- End Side Menu -->
    </header>
    <!-- End Site Header -->