<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
    <!-- Meta Tags -->
    <!--Optimization-->
    <meta charset="UTF-8" />
    <meta http-equiv="Expires" content="30" />
    <title>Future Revolution - A Digital Marketing, Web Design & Development Company in Bengaluru.</title>
    <meta name="description" content="Future Revolution is a Digital Marketing, Web Design & Development agency work with passion to solve your online business needs.">
    <meta name="keywords" content="Future Revolution, Website Development Bangalore, Website Design in Bangalore, Digital Marketing Services, Website designers bangalore, Website Development Companies in Bangalore, Website Design Company Bangalore.">
    <meta name="author" content="Future Revolution">
    <meta name="language" content="English">
    <meta name="revisit-after" content="1 days">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <!-- Favicon Icon -->
    <link rel="icon" href="assets/img/favicon.png">
    <!-- Stylesheets -->
    <link rel="stylesheet" type="text/css" href="assets/css/plugins.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="assets/css/responsive.css">
    <link id="theme" rel="stylesheet" href="assets/css/color/color-1.css">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
  <script type="text/javascript" src="assets/vendor/backward/html5shiv.js"></script>
  <script type="text/javascript" src="assets/vendor/backward/respond.min.js"></script>
  <![endif]-->
</head>

<body data-spy="scroll" data-target=".primary-nav">
    
    
       <?php include'includes/header.php' ?>
 

    <!-- Start Whatsapp and call plugin -->
  
    <!-- Start animation-version -->
    <section class="d-md-none d-lg-none d-xs-block d-sm-block">
        <img src="assets/img/slider.jpg" alt="" id="mobile-slider" class="img-responsive">
    </section>
    <section class="animation-version animation-version-2 d-none d-md-block d-lg-block d-xs-none d-sm-none" id="home">
        <img src="assets/img/slider.jpg" alt="" class="animation-bg img-responsive">
        <div class="stray-wave"></div>
        <div class="stray-wave stray-wave-2"></div>
        <!--
        <div class="slider-text">
            <h1>We Are Best Creative Business Agency</h1>
            <h2>10 years of experience helping businesses to find comprehensive solutions.</h2>
            <div class="but-group">
                <a href="#contact" class="tm-btn"><span>Contact Us</span></a>
            </div>
        </div>
-->
    </section>
    <!-- End animation-version -->

    <!-- Start About Us Section -->
    <section class="about-us about-us-2 section" id="about">
        <div class="container">
            <div class="section-head text-center">
                <h2>ABOUT US</h2>
                <div class="section-divider">
                    <div class="left wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                    <span></span>
                    <div class="right wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                </div>
                <p>One stop for all your business needs</p>
            </div>
            <div class="row">
                <div class="col-lg-7 col-xl-6">
                    <div class="about-company">
                        <h3>Welcome to our company</h3>
                        <p class="text-justify">Future Revolution is an innovative company which is aimed at providing new trends in the field of software designing and development. This is done in accordance with the software development standards to provide compatible software solutions. Future Revolution has a capacious domain savvy persons, with vast experience in technology. Our offshore Application Development team is best suited to understand and analyse the application requirements, then architect, develop, test its endurance, and finally deploy it to the clients with post project delivery management and support services.</p>
                    </div>
                </div><!-- .col -->
                <div class="col-lg-5 col-xl-6">
                    <!-- For youtube Video -->
                    <iframe width="560" height="100%" src="https://www.youtube.com/embed/XY_mVFFCv24" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div><!-- .col -->
            </div>
        </div>
    </section>
    <!-- End About Us Section -->

    <!-- Start Service Section -->
    <section class="service-section section" id="service">
        <div class="container">
            <div class="section-head text-center">
                <h2>SERVICE WE PROVIDE</h2>
                <div class="section-divider">
                    <div class="left wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                    <span></span>
                    <div class="right wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                </div>
                <p>Good Service is always a good business</p>
            </div>
            <div class="services">
                <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" data-toggle="tab" href="#one">
                            <i class="icofont icofont-architecture-alt"></i><span>Graphic Design</span>
                            <div class="active-bar"></div>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#two">
                            <i class="icofont-laptop"></i><span>Website Design</span>
                            <div class="active-bar"></div>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#three">
                            <i class="icofont-bulb-alt"></i><span>Web Development</span>
                            <div class="active-bar"></div>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#four">
                            <i class="icofont icofont-woman-bird"></i><span>Digital Marketing</span>
                            <div class="active-bar"></div>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#five">
                            <i class="fa fa-users"></i><span>Recruitment</span>
                            <div class="active-bar"></div>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#six">
                            <i class="icofont-chart-growth"></i><span>Tally Solutions</span>
                            <div class="active-bar"></div>
                        </a>
                    </li>
                </ul><!-- .nav-tabs -->
                <!-- Tab panes -->
                <div class="tab-content">
                    <div id="one" class="container tab-pane fade show active">
                        <div class="row">
                            <div class="col-lg-5">
                                <div class="service-text">
                                    <h3>Graphic Design</h3>
                                    <p>We furnish range of graphic design services to create an stunning business image, highly effective marketing medium and to make your business website engaging along with being appealing.</p>
                                    <a data-toggle="modal" data-target="#quotemodal" class="tm-btn"><span>Get A Quote</span></a>
                                </div>
                            </div><!-- .col -->
                            <div class="col-lg-7">
                                <div class="service-img"><img src="assets/img/service/graphicdesign.png" alt=""></div>
                            </div><!-- .col -->
                        </div><!-- .row -->
                    </div><!-- .tab-pane -->
                    <div id="two" class="container tab-pane fade">
                        <div class="row">
                            <div class="col-lg-5">
                                <div class="service-text">
                                    <h3>Website Design</h3>
                                    <p>Our in-house, web designing scholars and consider the fact that usability, functionality, and visualization are the three important factors of a website design.</p>
                                    <a data-toggle="modal" data-target="#quotemodal" class="tm-btn"><span>Get A Quote</span></a>
                                </div>
                            </div><!-- .col -->
                            <div class="col-lg-7">
                                <div class="service-img"><img src="assets/img/service/webdesign.png" alt=""></div>
                            </div><!-- .col -->
                        </div><!-- .row -->
                    </div><!-- .tab-pane -->
                    <div id="three" class="container tab-pane fade">
                        <div class="row">
                            <div class="col-lg-5">
                                <div class="service-text">
                                    <h3>Web Development</h3>
                                    <p>We are into developing web applications for the custom business requirements of all our esteemed clients. We provide extensible, scalable, responsive, rapid & secure custom web app development services that match client's business strategies and needs.</p>
                                    <a data-toggle="modal" data-target="#quotemodal" class="tm-btn"><span>Get A Quote</span></a>
                                </div>
                            </div><!-- .col -->
                            <div class="col-lg-7">
                                <div class="service-img"><img src="assets/img/service/web-development.png" alt=""></div>
                            </div><!-- .col -->
                        </div><!-- .row -->
                    </div><!-- .tab-pane -->
                    <div id="four" class="container tab-pane fade">
                        <div class="row">
                            <div class="col-lg-5">
                                <div class="service-text">
                                    <h3>Digital Marketing</h3>
                                    <p>We are a full-service digital marketing agency. We offer online solutions for all your digital channels and help your business grow. Our marketing Solutions provide innovation Search Engine solutions.</p>
                                    <a data-toggle="modal" data-target="#quotemodal" class="tm-btn"><span>Get A Quote</span></a>
                                </div>
                            </div><!-- .col -->
                            <div class="col-lg-7">
                                <div class="service-img"><img src="assets/img/service/digital-marketing.png" alt=""></div>
                            </div><!-- .col -->
                        </div><!-- .row -->
                    </div><!-- .tab-pane -->
                    <div id="five" class="container tab-pane fade">
                        <div class="row">
                            <div class="col-lg-5">
                                <div class="service-text">
                                    <h3>Recruitment</h3>
                                    <p>Want to outsource all the recruitment process or just need help? We can help! With years of experience in recruiting for national and international clients we help you with the best suited candidate.</p>
                                    <a data-toggle="modal" data-target="#quotemodal" class="tm-btn"><span>Get A Quote</span></a>
                                </div>
                            </div><!-- .col -->
                            <div class="col-lg-7">
                                <div class="service-img"><img src="assets/img/service/recuirtmentservice.png" alt=""></div>
                            </div><!-- .col -->
                        </div><!-- .row -->
                    </div><!-- .tab-pane -->
                    <div id="six" class="container tab-pane fade">
                        <div class="row">
                            <div class="col-lg-5">
                                <div class="service-text">
                                    <h3>Tally Solutions</h3>
                                    <p>We are Tally experts providing Tally services to customers operating from multiple locations. Tally Integration, Individual And Corporate Tally Training, Tally NET Services etc, Enquire Now!
                                    </p>
                                    <a data-toggle="modal" data-target="#quotemodal" class="tm-btn"><span>Get A Quote</span></a>
                                </div>
                            </div><!-- .col -->
                            <div class="col-lg-7">
                                <div class="service-img"><img src="assets/img/service/tally.png" alt=""></div>
                            </div><!-- .col -->
                        </div><!-- .row -->
                    </div><!-- .tab-pane -->
                </div>
            </div>
        </div>
    </section>
    <!-- End Service Section -->

    <!-- Start Work Process
    ============================================= -->
    <div id="process" class="work-process section">
        <div class="container">
            <div class="section-head text-center">
                <h2>Work Process</h2>
                <div class="section-divider">
                    <div class="left wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                    <span></span>
                    <div class="right wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                </div>
                <p>We want our clients to know what they’re receiving</p>
            </div>
            <div class="row">
                <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12 info">
                    <!-- Star Accordion Items -->
                    <ul id="accord1" class="accordian">
                        <li>
                            <header> <span>1</span> Building Strategies</header>
                            <section>
                                <p>We help you concentrate on your very best prospects and finding new genuine prospects — the ones who are most likely to do business with you soon and keep buying from you well into the future.</p>
                            </section>
                        </li>
                        <li>
                            <header> <span>2</span> Development</header>
                            <section>
                                <p>Once we understand your business goals and focus and have picked your key personas, it’s time when we will work with you to map each and everything out matching your prospects buyer’s expedition with your sales funnel.</p>
                            </section>
                        </li>
                        <li>
                            <header> <span>3</span> Design and Deployment</header>
                            <section>
                                <p>After the strategic plan and development, we move into the designing process. Our designers start with wireframes & prototypes and we further refine our ideas until the requirements are met.</p>
                            </section>
                        </li>
                        <li>
                            <header> <span>4</span> Optimization</header>
                            <section>
                                <p>This is where every single thing comes together before launch. Your new website, your messaging, and the visual design strategy, along with offers meant to attract new leads again and tripling your sales etc.</p>
                            </section>
                        </li>
                        <li>
                            <header> <span>5</span> Activation</header>
                            <section>
                                <p>We’re different from a regular traditional agency. We entitle. We escort. We teach and deliver. And, most importantly, we work with you to deploy a complete marketing strategy that will work for you.</p>
                            </section>
                        </li>
                    </ul>

                    <!-- End Accordion -->
                </div>
                <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                    <img src="assets/img/work-process.jpg">
                </div>
            </div>
        </div>
    </div>
    <!-- End Work Process -->

    <div class="height-100"></div>

    <!-- Start Call To Action -->
    <section class="cta section overlay-with-img cta-2">
        <img src="assets/img/call-to-action-bg.jpg" alt="" class="bg-img">
        <div class="fun-overlay"></div>
        <div class="container">
            <div class="cta-text">
                <div class="cta-btn">
                    <a href="#contact" class="tm-btn"><span>Contact Us</span></a>
                    <div class="cta-bar"></div>
                </div>
                <h2>
                    <span>
                        <span class="wow fadeInLeft" data-wow-duration="2s" data-wow-delay="0.1s">START BUILDING YOUR NEXT PROJECT WITH US</span>
                    </span>
                </h2>
            </div>
        </div>
    </section>
    <!-- End Call To Action -->

    <!-- Start Client Logo -->
    <div class="client-logo-wrap section" id="clients">
        <div class="container">
            <div class="section-head text-center">
                <h2>Our Clients</h2>
                <div class="section-divider">
                    <div class="left wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                    <span></span>
                    <div class="right wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                </div>
                <p>We work with organisations of any size</p>
            </div>

            <div class="container">
                <section class="customer-logos slider">
                    <div class="slide"><img src="assets/img/clients/1.png"></div>
                    <div class="slide"><img src="assets/img/clients/2.png"></div>
                    <div class="slide"><img src="assets/img/clients/3.png"></div>
                    <div class="slide"><img src="assets/img/clients/4.png"></div>
                    <div class="slide"><img src="assets/img/clients/5.png"></div>
                    <div class="slide"><img src="assets/img/clients/6.png"></div>
                    <div class="slide"><img src="assets/img/clients/7.png"></div>
                    <div class="slide"><img src="assets/img/clients/8.png"></div>
                    <div class="slide"><img src="assets/img/clients/9.png"></div>
                    <div class="slide"><img src="assets/img/clients/10.png"></div>
                    <div class="slide"><img src="assets/img/clients/11.png"></div>
                    <div class="slide"><img src="assets/img/clients/12.png"></div>
                </section>
            </div>
        </div>
    </div>
    <!-- End Client Logo -->

    <!-- Start Company Groth Section -->
    <section class="company-groth section overlay-with-img gray-bg company-groth-2">
        <div class="company-groth">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-xs-12 col-sm-12">
                        <div class="fun-fact">
                            <div class="col-md-3 col-xs-12 col-sm-6 no-padding">
                                <div class="single-fun-fact">
                                    <p class="counter">350</p>
                                    <i class="icofont icofont-tick-boxed"></i>
                                    <h2>Projects Delivered</h2>
                                </div><!-- .single-fun-fact -->
                            </div>
                            <div class="col-md-3 col-xs-12 col-sm-6 no-padding">
                                <div class="single-fun-fact">
                                    <p class="counter">150</p>
                                    <i class="icofont-businessman"></i>
                                    <h2>Happy Client</h2>
                                </div><!-- .single-fun-fact -->
                            </div>
                            <div class="col-md-3 col-xs-12 col-sm-6 no-padding">
                                <div class="single-fun-fact">
                                    <p class="counter">4</p>
                                    <i class="icofont icofont-architecture-alt"></i>
                                    <h2>Industry Experience</h2>
                                </div><!-- .single-fun-fact -->
                            </div>
                            <div class="col-md-3 col-xs-12 col-sm-6 no-padding">
                                <div class="single-fun-fact">
                                    <p class="counter">3</p>
                                    <i class="icofont icofont-location-arrow"></i>
                                    <h2>Business Locations</h2>
                                </div><!-- .single-fun-fact -->
                            </div>
                        </div>
                    </div><!-- .col -->
                </div>
            </div>
        </div>
    </section>
    <!-- End Company Groth Section -->

    <!-- Start Client Logo -->
    <div class="client-logo-wrap section" id="partner">
        <div class="container">
            <div class="section-head text-center">
                <h2>Our Partners</h2>
                <div class="section-divider">
                    <div class="left wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                    <span></span>
                    <div class="right wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                </div>
            </div>

            <div class="container partner-logo">
                <div class="row no-margin">
                    <div class="col-md-2 col-sm-6 col-xs-6">
                        <div class="slide"><img src="assets/img/partners/1.png"></div>
                    </div>
                    <div class="col-md-2 col-sm-6 col-xs-6">
                        <div class="slide"><img src="assets/img/partners/2.png"></div>
                    </div>
                    <div class="col-md-2 col-sm-6 col-xs-6">
                        <div class="slide"><img src="assets/img/partners/3.png"></div>
                    </div>
                    <div class="col-md-2 col-sm-6 col-xs-6">
                        <div class="slide"><img src="assets/img/partners/4.png"></div>
                    </div>
                    <div class="col-md-2 col-sm-6 col-xs-6">
                        <div class="slide"><img src="assets/img/partners/5.png"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Client Logo -->

    <div class="container section">
        <div class="section-head text-center">
            <h2>Testimonial</h2>
            <div class="section-divider">
                <div class="left wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                <span></span>
                <div class="right wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.2s"></div>
            </div>
        </div>
        <div class="container col-md-12">
            <div class="row">
                <div class="col-md-8 offset-md-2 col-lg-8 offset-lg-2 col-xs-12 col-sm-12">
                    <div id="testimonial-slider" class="owl-carousel">
                        <div class="testimonial">
                            <div class="pic">
                                <img src="assets/img/clients/bharadwaja.png">
                            </div>
                            <div class="testimonial-content">
                                <p>“We tried them all — Seamless, OrderAhead. When we found Future Revolution, it was easier for us to market and the price was better than anything out there.”
                                </p>
                            </div>
                            <h3 class="testimonial-title">
                                <small>Bharadwaj Karanth</small>
                            </h3>
                        </div>

                        <div class="testimonial">
                            <div class="pic">
                                <img src="assets/img/clients/dr.jpg">
                            </div>
                            <div class="testimonial-content">
                                <p>“We’ve increased our reputation from 20–25% since we’ve implemented Future Revolution and would never look back.”
                                </p>
                            </div>
                            <h3 class="testimonial-title">
                                <small>Dr.Rajesh Bairy</small>
                            </h3>
                        </div>

                        <div class="testimonial">
                            <div class="pic">
                                <img src="assets/img/clients/sriram.jpg">
                            </div>
                            <div class="testimonial-content">
                                <p>Thank you so much for delivering such an amazing website. Really impressed with the team and the way they have coordinated to understand the requirements. Amazing work and an excellent team to have worked with.
                                </p>
                            </div>
                            <h3 class="testimonial-title">
                                <small>Sriram Jamadagni</small>
                            </h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Start Contact Form -->
    <section class="contact-wrap section" id="contact">
        <div class="container">
            <div class="section-head text-center">
                <h2>Contact Us</h2>
                <div class="section-divider">
                    <div class="left wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                    <span></span>
                    <div class="right wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                </div>
                <p>We have solutions for all your queries</p>
            </div>
            <div class="row">
                <div class="col-lg-6">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3888.637053766959!2d77.58094631433386!3d12.931033219267029!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae15984144e82f%3A0x58c51acff4477aa!2sFuture+Revolution!5e0!3m2!1sen!2sin!4v1551432499036" width="100%" height="100%" frameborder="0" style="border:0" allowfullscreen></iframe>
                </div><!-- .col -->
                <div class="col-lg-6">
                    <form action="http://furecs.com/contact_mailer2.php" class="row contact-form" method="post" id="contact-form2" onSubmit="alert('Thank you for Contact. We will get back you soon.');">
                        <div class="col-lg-12">
                            <div class="tm-form-field">
                                <input type="text" id="name" name="form_name" required>
                                <span class="bar"></span>
                                <label>Full Name*</label>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="tm-form-field">
                                <input type="email" id="email" name="form_email" required>
                                <span class="bar"></span>
                                <label>Email Address*</label>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="tm-form-field">
                                <input type="number" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==10) return false;" id="phone" name="form_phone" required>
                                <span class="bar"></span>
                                <label>Phone*</label>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="tm-form-field">
                                <textarea cols="30" rows="10" id="msg" name="form_message" required></textarea>
                                <span class="bar"></span>
                                <label>Your Message*</label>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <button class="cont-submit btn-contact submit-btn tm-btn" type="submit" id="submit" name="submit">
                                <span>Send Message</span>
                                <i class="sp-btn"></i>
                            </button>
                        </div>
                    </form><!-- .row -->
                </div><!-- .col -->
            </div><!-- .row -->

        </div>
    </section>
    <!-- End Contact Form -->

    
    <?php include'includes/footer.php' ?>

</body>

</html>
