<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
    <!-- Meta Tags -->
    <!--Optimization-->
    <meta charset="UTF-8" />
    <meta http-equiv="Expires" content="30" />
    <title>Future Revolution - A Digital Marketing, Web Design & Development Company in Bengaluru.</title>
    <meta name="description" content="Future Revolution is a Digital Marketing, Web Design & Development agency work with passion to solve your online business needs.">
    <meta name="keywords" content="Future Revolution, Website Development Bangalore, Website Design in Bangalore, Digital Marketing Services, Website designers bangalore, Website Development Companies in Bangalore, Website Design Company Bangalore.">
    <meta name="author" content="Future Revolution">
    <meta name="language" content="English">
    <meta name="revisit-after" content="1 days">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <!-- Favicon Icon -->
    <link rel="icon" href="assets/img/favicon.png">
    <!-- Stylesheets -->
    <link rel="stylesheet" type="text/css" href="assets/css/plugins.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="assets/css/responsive.css">
    <link id="theme" rel="stylesheet" href="assets/css/color/color-1.css">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
  <script type="text/javascript" src="assets/vendor/backward/html5shiv.js"></script>
  <script type="text/javascript" src="assets/vendor/backward/respond.min.js"></script>
  <![endif]-->
</head>

<body data-spy="scroll" data-target=".primary-nav">


    <?php include'includes/header.php' ?>

    <!--Main Banner Breadcrumb-->
    <div class="banner_section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <a href="career.php">
                        <div title="Back to Menu" class="backArrow d-inline-block">
                            &#10140;
                        </div>
                    </a>&nbsp;&nbsp;
                    <h2 class="text-left d-inline-block">Job Details</h2>
                    <p><a href="index.php">Home</a> <span>/</span> Job Details</p>
                </div>
            </div>
        </div>
    </div>
    <!--End Banner-->

    <!-- contact area -->
    <div class="section">
        <div class="container">
            <div class="row">
                <!-- Start Job Title 
================================================== -->

                <div class="col-md-12 m-b10">
                    <h3><span class="job-title">Digital Marketing Executive</span></h3>

                </div>
                <!-- Start Company Logo 
    ================================================== -->
                <div class="col-md-1 col-sm-2 col-xs-2">
                    <div class="company-logo">
                        <img src="https://www.lcipl.com/wp-content/plugins/simple-job-board/public/images/company.png" alt="">
                    </div>
                </div>
                <!-- ========== End Company Logo =================  -->
                <div class="col-md-11 col-sm-10">
                    <div class="row">

                        <div class="col-md-5">
                            <div class="job-info_detail">
                                <h4>
                                    <span><a href="#" target="_blank" rel="nofollow">Future Revolution</a></span>
                                </h4>
                            </div>
                        </div>
                        <div class="col-md-2 col-sm-4">
                            <div class="job-type"><i class="fa fa-bookmark-o"></i><span> Full Time</span></div>

                        </div>
                        <div class="col-md-2 col-sm-4">
                            <div class="job-type"><i class="fa fa-map-marker"></i><span> Bangalore</span></div>

                        </div>
                        <div class="col-md-3 col-sm-4">
                            <div class="job-type"><i class="fa fa-calendar-check-o"></i><span> Posted 12 months ago</span></div>

                        </div>
                    </div>
                </div>

                <!-- ======= aJob description==================== -->
                <div class="col-md-12 m-t20">
                    <div class="job_desc">
                        <h4 class="m-b20">Job Description</h4>
                        <ul>
                            <li>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                tempor incididunt ut labore et dolore magna aliqua.</li>
                            <li>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                                consequat.</li>
                            <li> Excepteur sint occaecat cupidatat non
                                proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</li>
                            <li> Duis aute irure dolor in reprehenderit in voluptate velit esse
                                cillum dolore eu fugiat nulla pariatur.</li>
                        </ul>
                    </div>
                </div>

                <!-- ======= job feature==================== -->
                <div class="col-md-12 m-t20">
                    <div class="job-features">
                        <h4>Job Features</h4>
                        <table class="table">
                            <tbody>
                                <tr>
                                    <td>Role</td>
                                    <td>Digital Marketing Executive </td>
                                </tr>
                                <tr>
                                    <td>Experience</td>
                                    <td>6 Months to 2 Years </td>
                                </tr>
                                <tr>
                                    <td>Qualification</td>
                                    <td>+2, Any graduation, Post graduation </td>
                                </tr>
                                <tr>
                                    <td>Salary</td>
                                    <td> <span><i class="fa fa-rupee"></i> 12000 - <i class="fa fa-rupee"></i> 25000</span> </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- ======= apply onle form==================== -->
                <div class="col-md-12 m-b40">
                    <div class="row">
                        <div class="col-md-7">
                            <div class="job-online">
                                <h4>Apply online</h4>
                                <form action="#" class="jobpost-form">
                                    <div class="form-group">
                                        <label for="name">Name:</label>
                                        <input type="text" class="form-control" id="name" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="Email">Email:</label>
                                        <input type="email" class="form-control" id="Email" required="required">
                                    </div>
                                    <div class="form-group">
                                        <label for="phone">Phone:</label>
                                        <input type="text" class="form-control" id="phone" maxlength="10" required="required">
                                    </div>
                                    <div class="form-group">
                                        <label for="experience">Experience:</label>
                                        <select class="form-control" required>
                                            <option>Select</option>
                                            <option value="Fresher">Fresher</option>
                                            <option value="0-1">0-1 Year</option>
                                            <option value="1-2">1-2 Year</option>
                                            <option value="2-4">2-4 Year</option>
                                            <option value="4+">4+ Year</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="file">Attach Resume:</label>
                                        <input type="file" class="form-control" id="file" required="">
                                    </div>
                                    <button class="cont-submit btn-contact submit-btn tm-btn" type="submit" id="submit" name="submit">
                                        <span>Submit</span>
                                        <i class="sp-btn"></i>
                                    </button>
                                </form>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="upcoming-banner">
                                <img src="assets/img/upcoming-banner.jpg" alt="">
                                <div class="banner-content position-center">
                                    <h5 class="title">
                                        Apply For a Upcoming Jobs
                                    </h5>
                                    <a data-toggle="modal" data-target="#job_modal" class="au-btn au-btn-hover">Apply Now</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ==================================================
End Job Features -->

    <!-- line modal -->
    <div class="modal fade" id="job_modal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title" id="lineModalLabel">Apply For a Upcoming Jobs</h3>
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                </div>
                <div class="modal-body">

                    <!-- content goes here -->
                    <form action="#" class="upcoming-jobpost-form">
                        <div class="form-group">
                            <label for="name">Name:</label>
                            <input type="text" class="form-control" id="name" required="">
                        </div>
                        <div class="form-group">
                            <label for="Email">Email:</label>
                            <input type="email" class="form-control" id="Email" required="">
                        </div>
                        <div class="form-group">
                            <label for="phone">Phone:</label>
                            <input type="text" class="form-control" id="phone" maxlength="10" required="">
                        </div>
                        <div class="form-group">
                            <label for="experience">Experience:</label>
                            <select class="form-control">
                                <option>Select</option>
                                <option value="Fresher">Fresher</option>
                                <option value="0-1">0-1 Year</option>
                                <option value="1-2">1-2 Year</option>
                                <option value="2-4">2-4 Year</option>
                                <option value="4+">4+ Year</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="file">Attach Resume:</label>
                            <input type="file" class="form-control" id="file" required="">
                        </div>
                    </form>

                </div>
                <div class="modal-footer">
                    <button class="cont-submit btn-contact submit-btn tm-btn" type="submit" id="submit" name="submit">
                        <span>Submit</span>
                        <i class="sp-btn"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <?php include'includes/footer.php' ?>

</body>

</html>
