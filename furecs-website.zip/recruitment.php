<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
    <!-- Meta Tags -->
    <!--Optimization-->
    <meta charset="UTF-8" />
    <meta http-equiv="Expires" content="30" />
    <title>Future Revolution - A Digital Marketing, Web Design & Development Company in Bengaluru.</title>
    <meta name="description" content="Future Revolution is a Digital Marketing, Web Design & Development agency work with passion to solve your online business needs.">
    <meta name="keywords" content="Future Revolution, Website Development Bangalore, Website Design in Bangalore, Digital Marketing Services, Website designers bangalore, Website Development Companies in Bangalore, Website Design Company Bangalore.">
    <meta name="author" content="Future Revolution">
    <meta name="language" content="English">
    <meta name="revisit-after" content="1 days">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <!-- Favicon Icon -->
    <link rel="icon" href="assets/img/favicon.png">
    <!-- Stylesheets -->
    <link rel="stylesheet" type="text/css" href="assets/css/plugins.css">
    <link rel="stylesheet" href="assets/fonts/Flaticon.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="assets/css/responsive.css">
    <link id="theme" rel="stylesheet" href="assets/css/color/color-1.css">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
  <script type="text/javascript" src="assets/vendor/backward/html5shiv.js"></script>
  <script type="text/javascript" src="assets/vendor/backward/respond.min.js"></script>
  <![endif]-->
</head>

<body data-spy="scroll" data-target=".primary-nav">


    <?php include'includes/header.php' ?>

    <!--Main Banner Breadcrumb-->
    <div class="banner_section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="text-left d-inline-block">Recruitment</h2>
                    <p><a href="index.php">Home</a> <span>/</span> Services <span>/</span> Recruitment</p>
                </div>
            </div>
        </div>
    </div>
    <!--End Banner-->

    <section class="section">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6">
                    <div class="our-services-box p-4 mt-4">
                        <div class="services-icon-img mb-4">
                            <img src="assets/img/services-icon-bg.png" class="img-fluid d-block mx-auto">
                            <div class="our-services-icon text-center rounded">
                                <i class="flaticon-headphones"></i>
                            </div>
                        </div>

                        <div class="our-services-content text-center">
                            <h5 class="text-dark pt-4">Lorem Ipsum</h5>
                            <p class="text-muted mb-2">Itaque earum a rerum hic tenetur a sapiente delectus aut reiciendis voluptatibus maioresalias us.</p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="our-services-box p-4 mt-4">
                        <div class="services-icon-img mb-4">
                            <img src="assets/img/services-icon-bg.png" class="img-fluid d-block mx-auto">
                            <div class="our-services-icon text-center rounded">
                                <i class="flaticon-headphones"></i>
                            </div>
                        </div>

                        <div class="our-services-content text-center">
                            <h5 class="text-dark pt-4">Lorem Ipsum</h5>
                            <p class="text-muted mb-2"> Similique sunt in qui officia deserunt mollitia a laborum dolor quidem rerum facilis distinusctio.</p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="our-services-box p-4 mt-4">
                        <div class="services-icon-img mb-4">
                            <img src="assets/img/services-icon-bg.png" class="img-fluid d-block mx-auto">
                            <div class="our-services-icon text-center rounded">
                                <i class="flaticon-headphones"></i>
                            </div>
                        </div>

                        <div class="our-services-content text-center">
                            <h5 class="text-dark pt-4">Lorem Ipsum</h5>
                            <p class="text-muted mb-2">Nam libero tempore at cum soluta nobis est optio cumque imped minus placeat possisuntmus.</p>
                            
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="our-services-box p-4 mt-4">
                        <div class="services-icon-img mb-4">
                            <img src="assets/img/services-icon-bg.png" class="img-fluid d-block mx-auto">
                            <div class="our-services-icon text-center rounded">
                                <i class="flaticon-headphones"></i>
                            </div>
                        </div>

                        <div class="our-services-content text-center">
                            <h5 class="text-dark pt-4">Lorem Ipsum</h5>
                            <p class="text-muted mb-2">Sed ut perspiciatis unde omnis iste error sit optio voluptatem ast possisuntmus placeatape riam.</p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="our-services-box p-4 mt-4">
                        <div class="services-icon-img mb-4">
                            <img src="assets/img/services-icon-bg.png" class="img-fluid d-block mx-auto">
                            <div class="our-services-icon text-center rounded">
                                <i class="flaticon-headphones"></i>
                            </div>
                        </div>

                        <div class="our-services-content text-center">
                            <h5 class="text-dark pt-4">Lorem Ipsum</h5>
                            <p class="text-muted mb-2">Temporibus autem quibusdam et aut officiis debitis at rerum necessitatibus saepe evenietvol uptates.</p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="our-services-box p-4 mt-4">
                        <div class="services-icon-img mb-4">
                            <img src="assets/img/services-icon-bg.png" class="img-fluid d-block mx-auto">
                            <div class="our-services-icon text-center rounded">
                                <i class="flaticon-headphones"></i>
                            </div>
                        </div>

                        <div class="our-services-content text-center">
                            <h5 class="text-dark pt-4">Lorem Ipsum</h5>
                            <p class="text-muted mb-2">Aperiam eaque ipsa quae ab illo inventore veritatis quasi archite beatae vitae necessitatibus.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Start Call To Action -->
    <section class="cta section overlay-with-img cta-2">
        <img src="assets/img/call-to-action-bg.jpg" alt="" class="bg-img">
        <div class="fun-overlay"></div>
        <div class="container">
            <div class="cta-text">
                <div class="cta-btn">
                    <a href="#contact" class="tm-btn"><span>Contact Us</span></a>
                    <div class="cta-bar"></div>
                </div>
                <h2>
                    <span>
                        <span class="wow fadeInLeft" data-wow-duration="2s" data-wow-delay="0.1s">START BUILDING YOUR NEXT PROJECT WITH US</span>
                    </span>
                </h2>
            </div>
        </div>
    </section>
    <!-- End Call To Action -->


    <?php include'includes/footer.php' ?>

</body>

</html>
