<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
    <!-- Meta Tags -->
    <!--Optimization-->
    <meta charset="UTF-8" />
    <meta http-equiv="Expires" content="30" />
    <title>Future Revolution - A Digital Marketing, Web Design & Development Company in Bengaluru.</title>
    <meta name="description" content="Future Revolution is a Digital Marketing, Web Design & Development agency work with passion to solve your online business needs.">
    <meta name="keywords" content="Future Revolution, Website Development Bangalore, Website Design in Bangalore, Digital Marketing Services, Website designers bangalore, Website Development Companies in Bangalore, Website Design Company Bangalore.">
    <meta name="author" content="Future Revolution">
    <meta name="language" content="English">
    <meta name="revisit-after" content="1 days">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <!-- Favicon Icon -->
    <link rel="icon" href="assets/img/favicon.png">
    <!-- Stylesheets -->
    <link rel="stylesheet" type="text/css" href="assets/css/plugins.css">
    <link rel="stylesheet" href="assets/fonts/Flaticon.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="assets/css/responsive.css">
    <link id="theme" rel="stylesheet" href="assets/css/color/color-1.css">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
  <script type="text/javascript" src="assets/vendor/backward/html5shiv.js"></script>
  <script type="text/javascript" src="assets/vendor/backward/respond.min.js"></script>
  <![endif]-->
</head>

<body data-spy="scroll" data-target=".primary-nav">


    <?php include'includes/header.php' ?>

    <!--Main Banner Breadcrumb-->
    <div class="banner_section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="text-left d-inline-block">Tally Solutions</h2>
                    <p><a href="index.php">Home</a> <span>/</span> Services <span>/</span>Tally Solutions</p>
                </div>
            </div>
        </div>
    </div>
    <!--End Banner-->

    <!-- Start services section -->
    <div class="client-logo-wrap section">
        <div class="container">
            <div class="section-head text-center">
                <h2>Tally Solutions</h2>
                <div class="section-divider">
                    <div class="left wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                    <span></span>
                    <div class="right wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <p class="text-justify">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p><br />
                    </div>
                    <div class="col-md-6">
                        <iframe width="100%" height="100%" src="https://www.youtube.com/embed/H_z86iYOauQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
                <div class="row">
                    <!--Services Section-->
                    <div class="development-services-area section">
                        <div class="container">
                            <div class="development-service-list">
                                <div class="row">
                                    <div class="col-lg-3 col-md-6">
                                        <div class="development-single-services text-center">
                                            <div class="development-service-icon">
                                                <img src="assets/img/tally/connected-capabilities.png">
                                            </div>
                                            <div class="development-service-title">
                                                <h4>SIMPLICITY</h4>
                                            </div>
                                            <div class="development-service-content">
                                                <p class="text-justify">Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-6">
                                        <div class="development-single-services text-center">
                                            <div class="development-service-icon">
                                                <img src="assets/img/tally/flexibility-icon.png">
                                            </div>
                                            <div class="development-service-title">
                                                <h4>FLEXIBILITY</h4>
                                            </div>
                                            <div class="development-service-content">
                                                <p class="text-justify">Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-6">
                                        <div class="development-single-services text-center">
                                            <div class="development-service-icon">
                                                <img src="assets/img/tally/reliability-icon.png">
                                            </div>
                                            <div class="development-service-title">
                                                <h4>RELIABILITY</h4>
                                            </div>
                                            <div class="development-service-content">
                                                <p class="text-justify">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 col-md-6">
                                        <div class="development-single-services text-center">
                                            <div class="development-service-icon">
                                                <img src="assets/img/tally/speed-icon.png">
                                            </div>
                                            <div class="development-service-title">
                                                <h4>SPEED</h4>
                                            </div>
                                            <div class="development-service-content">
                                                <p class="text-justify">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End Services Section-->

                    <!-- Start KEY BENEFITS SECTION -->
                    <div class="benefits-wrap section">
                        <div class="container">
                            <div class="section-head text-center">
                                <h2>KEY BENEFITS OF TALLY.ERP 9</h2>
                                <div class="section-divider">
                                    <div class="left wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                                    <span></span>
                                    <div class="right wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                                </div>
                            </div>
                            <div class="container border border-danger p-t30">
                                <div class="row m-b20">
                                    <div class="col-md-6">
                                        <img src="assets/img/tally/tally-banner.jpg" class="img-responsive" width="100%" height="100%">
                                    </div>
                                    <div class="col-md-6">
                                        <h4 class="tally-benefits-title">
                                            <b>MANAGE YOUR ACCOUNTS EASILY</b>
                                        </h4>
                                        <p class="text-justify p-t15">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p><br />
                                    </div>
                                </div>
                                <div class="row m-b20">
                                    <div class="col-md-6">
                                        <h4 class="tally-benefits-title">
                                            <b>YOUR ONE-STOP GST READY SOLUTION</b>
                                        </h4>
                                        <p class="text-justify p-t15">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p><br />
                                    </div>
                                    <div class="col-md-6">
                                        <img src="assets/img/tally/tally-banner.jpg" class="img-responsive" width="100%" height="100%">
                                    </div>
                                </div>
                                <div class="row m-b20">
                                    <div class="col-md-6">
                                        <img src="assets/img/tally/tally-banner.jpg" class="img-responsive" width="100%" height="100%">
                                    </div>
                                    <div class="col-md-6">
                                        <h4 class="tally-benefits-title">
                                            <b>BANKING MADE EASY FOR YOU</b>
                                        </h4>
                                        <p class="text-justify p-t15">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p><br />
                                    </div>
                                </div>
                                <div class="row m-b20">
                                    <div class="col-md-6">
                                        <h4 class="tally-benefits-title">
                                            <b>TAKE DECISIONS ON THE GO</b>
                                        </h4>
                                        <p class="text-justify p-t15">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p><br />
                                    </div>
                                    <div class="col-md-6">
                                        <img src="assets/img/tally/tally-banner.jpg" class="img-responsive" width="100%" height="100%">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End KEY BENEFITS SECTION -->

                    <!-- Start FEATURES SECTION -->
                    <div class="benefits-wrap section">
                        <div class="container">
                            <div class="section-head text-center">
                                <h2>TALLY.ERP 9 FEATURES</h2>
                                <div class="section-divider">
                                    <div class="left wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                                    <span></span>
                                    <div class="right wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                                </div>
                            </div>
                            <div class="container">
                                <div class="row m-b20">
                                    <div class="col-xs-12 col-sm-2 features-blocks-tab">
                                        <div class="seo-media-images text-center">
                                            <img src="//tallysolutions.com/wp-content/uploads/2018/03/simple-accounting-management-icon-1.png" alt="simple accounting management" /></div>
                                        <h5>simple accounting management</h5>
                                    </div>
                                    <div class="col-xs-12 col-sm-2 features-blocks-tab">
                                        <div class="seo-media-images text-center">
                                            <img src="//tallysolutions.com/wp-content/uploads/2018/03/compliance-icon-1.png" alt="//tallysolutions.com/wp-content/uploads/2018/03/compliance-icon-1.png" /></div>
                                        <h5>one stop solution for compliance</h5>
                                    </div>
                                    <div class="col-xs-12 col-sm-2 features-blocks-tab">
                                        <div class="seo-media-images text-center">
                                            <img src="//tallysolutions.com/wp-content/uploads/2016/12/banking-transaction-icon.png" alt="//tallysolutions.com/wp-content/uploads/2016/12/banking-transaction-icon.png" /></div>
                                        <h5>support for banking transactions</h5>
                                    </div>
                                    <div class="col-xs-12 col-sm-2 features-blocks-tab">
                                        <div class="seo-media-images text-center">
                                            <img src="//tallysolutions.com/wp-content/uploads/2018/03/business-reports-icon-1.png" alt="//tallysolutions.com/wp-content/uploads/2018/03/business-reports-icon-1.png" /></div>
                                        <h5>Faster Access to business reports</h5>
                                    </div>
                                    <div class="col-xs-12 col-sm-2 features-blocks-tab">
                                        <div class="seo-media-images text-center">
                                            <img src="//tallysolutions.com/wp-content/uploads/2017/04/Inventory-Management.png" alt="inventory management" /></div>
                                        <h5>flexible inventory management</h5>
                                    </div>
                                    <div class="col-xs-12 col-sm-2 features-blocks-tab">
                                        <div class="seo-media-images text-center">
                                            <img src="//tallysolutions.com/wp-content/uploads/2018/03/application-management-icon-1.png" alt="//tallysolutions.com/wp-content/uploads/2018/03/application-management-icon-1.png" /></div>
                                        <h5>Easy application management</h5>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-xs-12 col-sm-2 features-blocks-tab">
                                        <div class="seo-media-images text-center">
                                            <img src="//tallysolutions.com/wp-content/uploads/2018/03/easy-share-icon-1.png" alt="//tallysolutions.com/wp-content/uploads/2018/03/easy-share-icon-1.png" /></div>
                                        <h5>Easy to share</h5>
                                    </div>
                                    <div class="col-xs-12 col-sm-2 features-blocks-tab">
                                        <div class="seo-media-images text-center">
                                            <img src="//tallysolutions.com/wp-content/uploads/2017/04/Payroll.png" alt="payroll managemnt" /></div>
                                        <h5 style="text-align: center;">Payroll management</h5>
                                    </div>
                                    <div class="col-xs-12 col-sm-2 features-blocks-tab">
                                        <div class="seo-media-images text-center">
                                            <img src="//tallysolutions.com/wp-content/uploads/2016/12/budgets-controls-icon.png" alt="budgets" /></div>
                                        <h5 style="text-align: center;">Budgets and controls</h5>
                                    </div>
                                    <div class="col-xs-12 col-sm-2 features-blocks-tab">
                                        <div class="seo-media-images text-center">
                                            <img src="//tallysolutions.com/wp-content/uploads/2017/04/Manufacturing.png" alt="manufacturers" /></div>
                                        <h5 style="text-align: center;">support for manufacturers</h5>
                                    </div>
                                    <div class="col-xs-12 col-sm-2 features-blocks-tab">
                                        <div class="seo-media-images text-center">
                                            <img src="//tallysolutions.com/wp-content/uploads/2018/03/multilingual-capabilities-icon-1.png" alt="//tallysolutions.com/wp-content/uploads/2018/03/multilingual-capabilities-icon-1.png" /></div>
                                        <h5 style="text-align: center;">Multilingual capabilities</h5>
                                    </div>
                                    <div class="col-xs-12 col-sm-2 features-blocks-tab">
                                        <div class="seo-media-images text-center">
                                            <img src="//tallysolutions.com/wp-content/uploads/2017/04/Application-Data-and-Security-Management.png" alt="enhanced security" /></div>
                                        <h5 style="text-align: center;">Enhanced security</h5>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <!-- End FEATURES SECTION -->

                <!-- Start TALLY SERVER 9 SECTION -->
                <div class="section">
                    <div class="container">
                        <div class="section-head text-center">
                            <h2>TALLY.ERP 9 SERVER</h2>
                            <div class="section-divider">
                                <div class="left wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                                <span></span>
                                <div class="right wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                            </div>
                        </div>
                        <div class="container border border-danger p-t30">
                            <div class="row m-b20">
                                <div class="col-md-6">
                                    <img src="assets/img/tally/tally-banner.jpg" class="img-responsive" width="100%" height="100%">
                                </div>
                                <div class="col-md-6">
                                    <p class="text-justify p-t15">Tally.Server 9 is an Enterprise Class product that helps fast growing medium and large size businesses to improve their business efficiencies. It enhances the power and control of Tally.ERP 9 Gold users by converting the existing 'peer-to-peer' kind of data access to 'server based' data management.</p>
                                    <ul class="tally_list_style">
                                        <li><i class="fa fa-check"></i> High Concurrency</li>
                                        <li><i class="fa fa-check"></i> Improved Security</li>
                                        <li><i class="fa fa-check"></i> High Reliability</li>
                                        <li><i class="fa fa-check"></i> Business Process Optimization</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- END TALLY SERVER 9 SECTION -->


                    <!-- Start Tally Software Services SECTION -->
                    <div class="section">
                        <div class="container">
                            <div class="section-head text-center">
                                <h2>Tally Software Services</h2>
                                <div class="section-divider">
                                    <div class="left wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                                    <span></span>
                                    <div class="right wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                                </div>
                            </div>
                            <div class="container p-t30">
                                <div class="row m-b20">
                                    <div class="col-md-6">
                                        <img src="assets/img/tally/tally-banner.jpg" class="img-responsive" width="100%" height="100%">
                                    </div>
                                    <div class="col-md-6">
                                        <p class="text-justify p-t15">Tally Software Services (TSS) is a software subscription for a collection of services which add great value to your Tally.ERP 9 by giving you additional features. Connectivity driven functionalities such as continuous upgrades & updates, central consolidation of branch data, instant support from within your Tally.ERP 9 and much more, enhance your business performance by leaps and bounds.</p>
                                        <div class="col-md-12">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <ul class="tally_list_style">
                                                        <li><i class="fa fa-check"></i> Product updates</li>
                                                        <li><i class="fa fa-check"></i> Data Synchronisation</li>
                                                        <li><i class="fa fa-check"></i> Remote Access</li>
                                                        <li><i class="fa fa-check"></i> TallyShop</li>
                                                    </ul>
                                                </div>
                                                <div class="col-md-6">
                                                    <ul class="tally_list_style">
                                                        <li><i class="fa fa-check"></i> Statutory Requirements</li>
                                                        <li><i class="fa fa-check"></i> Audit Tools</li>
                                                        <li><i class="fa fa-check"></i> Banking & Payment</li>
                                                        <li><i class="fa fa-check"></i> Self-help Support</li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- END TALLY SERVER 9 SECTION -->

                    </div>
                </div>
            </div>
        </div>



        <!-- Start Call To Action -->
        <section class="cta section overlay-with-img cta-2">
            <img src="assets/img/call-to-action-bg.jpg" alt="" class="bg-img">
            <div class="fun-overlay"></div>
            <div class="container">
                <div class="cta-text">
                    <div class="cta-btn">
                        <a href="#contact" class="tm-btn"><span>Contact Us</span></a>
                        <div class="cta-bar"></div>
                    </div>
                    <h2>
                        <span>
                            <span class="wow fadeInLeft" data-wow-duration="2s" data-wow-delay="0.1s">START BUILDING YOUR NEXT PROJECT WITH US</span>
                        </span>
                    </h2>
                </div>
            </div>
        </section>
        <!-- End Call To Action -->


        <?php include'includes/footer.php' ?>

</body>

</html>
