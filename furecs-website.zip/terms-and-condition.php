<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
    <!-- Meta Tags -->
    <!--Optimization-->
    <meta charset="UTF-8" />
    <meta http-equiv="Expires" content="30" />
    <title>Future Revolution - A Digital Marketing, Web Design & Development Company in Bengaluru.</title>
    <meta name="description" content="Future Revolution is a Digital Marketing, Web Design & Development agency work with passion to solve your online business needs.">
    <meta name="keywords" content="Future Revolution, Website Development Bangalore, Website Design in Bangalore, Digital Marketing Services, Website designers bangalore, Website Development Companies in Bangalore, Website Design Company Bangalore.">
    <meta name="author" content="Future Revolution">
    <meta name="language" content="English">
    <meta name="revisit-after" content="1 days">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <!-- Favicon Icon -->
    <link rel="icon" href="assets/img/favicon.png">
    <!-- Stylesheets -->
    <link rel="stylesheet" type="text/css" href="assets/css/plugins.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="assets/css/responsive.css">
    <link id="theme" rel="stylesheet" href="assets/css/color/color-1.css">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
  <script type="text/javascript" src="assets/vendor/backward/html5shiv.js"></script>
  <script type="text/javascript" src="assets/vendor/backward/respond.min.js"></script>
  <![endif]-->
</head>

<body data-spy="scroll" data-target=".primary-nav">


    <?php include'includes/header.php' ?>

    <!--Main Banner Breadcrumb-->
    <div class="banner_section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="text-left">Terms &amp; Conditions</h2>
                    <p><a href="index.php">Home</a> <span>/</span> Terms &amp; Conditions</p>
                </div>
            </div>
        </div>
    </div>
    <!--End Banner-->

    <div class="section">
        <div class="container">
            <div class="section-head text-center">
                <h2>Terms &amp; Conditions</h2>
                <div class="section-divider">
                    <div class="left wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                    <span></span>
                    <div class="right wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                </div>
            </div>
            <div class="container">
                <p>
                    The following terms and conditions apply to all website development / design Digital marketing services provided by Future Revolution Consultancy Pvt LTD to the Client.
                </p>
                <br />
                <h3>1. Acceptance</h3>
                <p>It is not necessary for any Client to have signed an acceptance of these terms and conditions for them to apply. If a Client accepts a quote then the Client will be deemed to have satisfied themselves as to the terms applying and have accepted these terms and conditions in full.</p>
                <p>Please read these terms and conditions carefully. Any purchase or use of our services implies that you have read and accepted our terms and conditions.</p>
                <br />
                <h3>2. Client Review</h3>
                <p>Future Revolution Consultancy Pvt LTD will provide the Client with an opportunity to review the appearance and content of the website during the design phase and once the overall website development is completed. At the completion of the project, such materials will be deemed to be accepted and approved unless the Client notifies Future Revolution Consultancy Pvt LTD otherwise within ten (10) days of the date the materials are made available to the Client.</p>
                <p>In return, the Client agrees to delegate a single individual as a primary contact to aid Future Revolution Consultancy Pvt LTD with progressing the commission in a satisfactory and expedient manner.</p>
                <p>During the project, Future Revolution Consultancy Pvt LTD will require the Client to provide website content; text, images, movies and sound files</p>
                <br />
                <h3>3. Failure to provide required website content:</h3>
                <p>Future Revolution Consultancy Pvt LTD is a small business, to remain efficient we must ensure that work we have programmed is carried out at the scheduled time. On occasions we may have to reject offers for other work and enquiries to ensure that your work is completed at the time arranged.</p>
                <p>This is why we ask that you provide all the required information in advance. On any occasion where progress cannot be made with your website because we have not been given the required information in the agreed time frame, and we are delayed as result, we reserve the right to impose a surcharge of up to 25%. If your project involves Search Engine Optimisation we need the text content for your site in advance so that the SEO can be planned and completed efficiently.</p>
                <p>If you agree to provide us with the required information and subsequently fail to do within one week of project commencement we reserve the right to close the project and the balance remaining becomes payable immediately. Simply put, all the above condition says is do not give us the go ahead to start until you are ready to do so.</p>
                <p>NOTE: Text content should be delivered as a Microsoft Word, email (or similar) document with the pages in the supplied document representing the content of the relevant pages on your website. These pages should have the same titles as the agreed website pages. Contact us if you need clarification on this.</p>
                <p>Using our content management system you are able to keep your content up to date yourself.</p>
                <br />
                <h3>4. Payment</h3>
                <p>A cookie is a small file which asks permission to be placed on your computer's hard drive. Once you agree to it robe placed, the file is added and the cookie helps analyze web traffic or lets you know when you visit a particular site. Cookies allow web applications to respond to you as a single individual...</p>
                <p>Overall, cookies help us provide you with a better website, by enabling us to monitor which pages you find useful and which you do not. A cookie in no way gives us access to your computer or any information about you, other than the data you choose to share with us.</p>
                <p>You can choose to accept or decline cookies. Most web browsers automatically accept cookies, but you can usually modify your browser setting to decline cookies if you prefer. This may prevent you from taking full advantage of the website.</p>
                <br /><br />
            </div>

        </div>
    </div>



    <?php include'includes/footer.php' ?>

</body>

</html>
