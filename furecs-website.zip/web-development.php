<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
    <!-- Meta Tags -->
    <!--Optimization-->
    <meta charset="UTF-8" />
    <meta http-equiv="Expires" content="30" />
    <title>Future Revolution - A Digital Marketing, Web Design & Development Company in Bengaluru.</title>
    <meta name="description" content="Future Revolution is a Digital Marketing, Web Design & Development agency work with passion to solve your online business needs.">
    <meta name="keywords" content="Future Revolution, Website Development Bangalore, Website Design in Bangalore, Digital Marketing Services, Website designers bangalore, Website Development Companies in Bangalore, Website Design Company Bangalore.">
    <meta name="author" content="Future Revolution">
    <meta name="language" content="English">
    <meta name="revisit-after" content="1 days">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <!-- Favicon Icon -->
    <link rel="icon" href="assets/img/favicon.png">
    <!-- Stylesheets -->
    <link rel="stylesheet" type="text/css" href="assets/css/plugins.css">
    <link rel="stylesheet" href="assets/fonts/Flaticon.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="assets/css/responsive.css">
    <link id="theme" rel="stylesheet" href="assets/css/color/color-1.css">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
  <script type="text/javascript" src="assets/vendor/backward/html5shiv.js"></script>
  <script type="text/javascript" src="assets/vendor/backward/respond.min.js"></script>
  <![endif]-->
</head>

<body data-spy="scroll" data-target=".primary-nav">


    <?php include'includes/header.php' ?>

    <!--Main Banner Breadcrumb-->
    <div class="banner_section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="text-left d-inline-block">Website Devepment</h2>
                    <p><a href="index.php">Home</a> <span>/</span> Services <span>/</span> Website Development</p>
                </div>
            </div>
        </div>
    </div>
    <!--End Banner-->

    <!-- Start Client Logo -->
    <div class="client-logo-wrap section">
        <div class="container">
            <div class="section-head text-center">
                <h2>Website Development</h2>
                <div class="section-divider">
                    <div class="left wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                    <span></span>
                    <div class="right wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <p class="text-justify">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p><br />
                    <p class="text-justify">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p><br />
                </div>
                <div class="row">
                    
                </div>
            </div>
        </div>
    </div>

    <!--start work process Section-->

    <div class="work-porcess-area section white">
        <div class="container">
            <div class="row">
                <div class="section-head text-center">
                    <h2>Web Development Work Process</h2>
                    <div class="section-divider">
                        <div class="left wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                        <span></span>
                        <div class="right wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                    </div>
                </div>
            </div>
            <div class="process-info">
                <div class="row">
                    <div class="col-md-3">
                        <div class="single-process first text-center">
                            <i class="flaticon-calendar"></i>
                            <h4>Planning</h4>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="single-process secend text-center">
                            <i class="flaticon-settings"></i>
                            <h4>Development</h4>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="single-process thard text-center">
                            <i class="flaticon-send-message-button"></i>
                            <h4>Test & Launch</h4>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="single-process last text-center">
                            <i class="flaticon-timer"></i>
                            <h4>Maintenance</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--end process Section-->

    <!-- Start Call To Action -->
    <section class="cta section overlay-with-img cta-2">
        <img src="assets/img/call-to-action-bg.jpg" alt="" class="bg-img">
        <div class="fun-overlay"></div>
        <div class="container">
            <div class="cta-text">
                <div class="cta-btn">
                    <a href="#contact" class="tm-btn"><span>Contact Us</span></a>
                    <div class="cta-bar"></div>
                </div>
                <h2>
                    <span>
                        <span class="wow fadeInLeft" data-wow-duration="2s" data-wow-delay="0.1s">START BUILDING YOUR NEXT PROJECT WITH US</span>
                    </span>
                </h2>
            </div>
        </div>
    </section>
    <!-- End Call To Action -->


    <?php include'includes/footer.php' ?>

</body>

</html>
