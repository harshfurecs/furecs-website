<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
    <!-- Meta Tags -->
    <!--Optimization-->
    <meta charset="UTF-8" />
    <meta http-equiv="Expires" content="30" />
    <title>Future Revolution - A Digital Marketing, Web Design & Development Company in Bengaluru.</title>
    <meta name="description" content="Future Revolution is a Digital Marketing, Web Design & Development agency work with passion to solve your online business needs.">
    <meta name="keywords" content="Future Revolution, Website Development Bangalore, Website Design in Bangalore, Digital Marketing Services, Website designers bangalore, Website Development Companies in Bangalore, Website Design Company Bangalore.">
    <meta name="author" content="Future Revolution">
    <meta name="language" content="English">
    <meta name="revisit-after" content="1 days">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <!-- Favicon Icon -->
    <link rel="icon" href="assets/img/favicon.png">
    <!-- Stylesheets -->
    <link rel="stylesheet" type="text/css" href="assets/css/plugins.css">
    <link rel="stylesheet" href="assets/fonts/Flaticon.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="assets/css/responsive.css">
    <link id="theme" rel="stylesheet" href="assets/css/color/color-1.css">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
  <script type="text/javascript" src="assets/vendor/backward/html5shiv.js"></script>
  <script type="text/javascript" src="assets/vendor/backward/respond.min.js"></script>
  <![endif]-->
</head>

<body data-spy="scroll" data-target=".primary-nav">


    <?php include'includes/header.php' ?>

    <!--Main Banner Breadcrumb-->
    <div class="banner_section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="text-left d-inline-block">Website Design</h2>
                    <p><a href="index.php">Home</a> <span>/</span> Services <span>/</span> Website Design</p>
                </div>
            </div>
        </div>
    </div>
    <!--End Banner-->

    <!-- Start Client Logo -->
    <div class="client-logo-wrap section">
        <div class="container">
            <div class="section-head text-center">
                <h2>Website Design</h2>
                <div class="section-divider">
                    <div class="left wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                    <span></span>
                    <div class="right wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <p class="text-justify">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p><br />
                    <p class="text-justify">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p><br />
                </div>
                <div class="row">
                    <!--Services Section-->
                    <section class="services-section-three style-two">
                        <div class="auto-container">
                            <div class="section-head text-center">
                                <h2>Discover services we’r provided</h2>
                                <div class="section-divider">
                                    <div class="left wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                                    <span></span>
                                    <div class="right wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.2s"></div>
                                </div>
                            </div>
                            <div class="row clearfix">

                                <!--Services Block-->
                                <div class="services-block col-md-4 col-sm-6 col-xs-12">
                                    <div class="inner-box wow fadeIn" data-wow-delay="0ms" data-wow-duration="1500ms">
                                        <div class="left-layer"></div>
                                        <div class="right-layer"></div>
                                        <div class="big-letter">Static</div>
                                        <div class="icon-box">
                                            <span class="icon flaticon-graphic"></span>
                                        </div>
                                        <h2><a href="#">Static Website</a></h2>
                                        <div class="title">5 Page Website</div>
                                        <div class="text text-justify">Web pages with the fixed content. Most easiest to create than dynamic webiste.
                                            Static webites are cost effective, well suite for small scale businesses as it does not require any administrative setup, available at reasonable costs, quick designing and development process and easy to optimise with free maintenance.</div>
                                    </div>
                                </div>

                                <!--Services Block-->
                                <div class="services-block col-md-4 col-sm-6 col-xs-12">
                                    <div class="inner-box wow fadeIn" data-wow-delay="500ms" data-wow-duration="1500ms">
                                        <div class="left-layer"></div>
                                        <div class="right-layer"></div>
                                        <div class="big-letter">Parallax</div>
                                        <div class="icon-box">
                                            <span class="icon flaticon-resume"></span>
                                        </div>
                                        <h2><a href="#">Parallax website</a></h2>
                                        <div class="title">Single Page</div>
                                        <div class="text text-justify">Parallax scrolling is a popular design technique used on websites in order to create an illusion of movement on the screen, to help engage website visitors and enhance the user experience. This cool 3D-like design concept allows users to scroll up and down a page at different speeds, while images on various layers move at different rates to give the page more visual depth and dimension to give the user a more seamless experience.</div>
                                    </div>
                                </div>

                                <!--Services Block-->
                                <div class="services-block col-md-4 col-sm-6 col-xs-12">
                                    <div class="inner-box wow fadeIn" data-wow-delay="1000ms" data-wow-duration="1500ms">
                                        <div class="left-layer"></div>
                                        <div class="right-layer"></div>
                                        <div class="big-letter">CMS</div>
                                        <div class="icon-box">
                                            <span class="icon flaticon-customer"></span>
                                        </div>
                                        <h2><a href="#">CMS</a></h2>
                                        <div class="title">Dynamic</div>
                                        <div class="text text-justify">Content Management System) quite literally allows you to manage and control content within your website without any technical support. CMS have become one of the internet’s most powerful web developer tool since php. There are several other reasons but important being editing content is easy and simple.</div>
                                    </div>
                                </div>

                                <!--Services Block-->
                                <div class="services-block col-md-4 col-sm-6 col-xs-12">
                                    <div class="inner-box wow fadeIn" data-wow-delay="0ms" data-wow-duration="1500ms">
                                        <div class="left-layer"></div>
                                        <div class="right-layer"></div>
                                        <div class="big-letter">Responsive</div>
                                        <div class="icon-box">
                                            <span class="icon flaticon-diamond"></span>
                                        </div>
                                        <h2><a href="#">Responsive Web design</a></h2>
                                        <div class="title">increase your device accessibility</div>
                                        <div class="text text-justify">RWD is an approach that allows design and code to respond to all the available size of a device’s screen, wherein the user gets optimal viewing experience.</div>
                                    </div>
                                </div>

                                <!--Services Block-->
                                <div class="services-block col-md-4 col-sm-6 col-xs-12">
                                    <div class="inner-box wow fadeIn" data-wow-delay="500ms" data-wow-duration="1500ms">
                                        <div class="left-layer"></div>
                                        <div class="right-layer"></div>
                                        <div class="big-letter">Testing</div>
                                        <div class="icon-box">
                                            <span class="icon flaticon-pie-chart"></span>
                                        </div>
                                        <h2><a href="#">Cross Browser Testing</a></h2>
                                        <div class="title">SEO, Marketing</div>
                                        <div class="text text-justify">Cross Browser Testing is a type of testing to verify if an application works across different browsers as expected and degrades gracefully. It is the process of verifying your application’s compatibility with different browsers.</div>
                                    </div>
                                </div>

                                <!--Services Block-->
                                <div class="services-block col-md-4 col-sm-6 col-xs-12">
                                    <div class="inner-box wow fadeIn" data-wow-delay="1000ms" data-wow-duration="1500ms">
                                        <div class="left-layer"></div>
                                        <div class="right-layer"></div>
                                        <div class="big-letter">Maintenance</div>
                                        <div class="icon-box">
                                            <span class="icon flaticon-quality"></span>
                                        </div>
                                        <h2><a href="#">Maintenance</a></h2>
                                        <div class="title">Optimized Web Maintenance</div>
                                        <div class="text text-justify">Performing all the tasks necessary to keep a website up to date and in good, working order so that it works and shows up correctly with the latest web browsers and mobile devices.</div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </section>
                    <!--End Services Section-->


                </div>
            </div>
        </div>
    </div>

    <!-- Start Call To Action -->
    <section class="cta section overlay-with-img cta-2">
        <img src="assets/img/call-to-action-bg.jpg" alt="" class="bg-img">
        <div class="fun-overlay"></div>
        <div class="container">
            <div class="cta-text">
                <div class="cta-btn">
                    <a href="#contact" class="tm-btn"><span>Contact Us</span></a>
                    <div class="cta-bar"></div>
                </div>
                <h2>
                    <span>
                        <span class="wow fadeInLeft" data-wow-duration="2s" data-wow-delay="0.1s">START BUILDING YOUR NEXT PROJECT WITH US</span>
                    </span>
                </h2>
            </div>
        </div>
    </section>
    <!-- End Call To Action -->


    <?php include'includes/footer.php' ?>

</body>

</html>
